import type { Config, Context } from "@netlify/functions";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { communityPosts } from "../../db/schema.js";
import { failure, HttpError, PART_BYTES, UUID_PATTERN } from "../lib/http.js";
import { mediaStore } from "../lib/posts.js";

export default async (request: Request, context: Context) => {
  try {
    if (!["GET", "HEAD"].includes(request.method)) throw new HttpError(405, "Method not allowed.");
    const id = context.params.id;
    if (!id || !UUID_PATTERN.test(id)) throw new HttpError(404, "Media not found.");
    const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
    if (!post) throw new HttpError(404, "Media not found.");
    const headers: Record<string, string> = {
      "Content-Type": post.contentType, "X-Content-Type-Options": "nosniff", "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=300", "Content-Length": String(post.mediaBytes),
    };
    if (request.method === "HEAD") return new Response(null, { headers });
    let start = 0;
    let end = post.mediaBytes - 1;
    const range = request.headers.get("range");
    if (range) {
      const match = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!match || (!match[1] && !match[2])) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${post.mediaBytes}` } });
      if (!match[1]) {
        const suffix = Number(match[2]);
        if (!Number.isSafeInteger(suffix) || suffix <= 0) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${post.mediaBytes}` } });
        start = Math.max(0, post.mediaBytes - suffix);
      } else {
        start = Number(match[1]);
        end = match[2] ? Math.min(end, Number(match[2])) : end;
      }
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start >= post.mediaBytes || end < start) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${post.mediaBytes}` } });
      end = Math.min(end, start + PART_BYTES - 1);
      headers["Content-Range"] = `bytes ${start}-${end}/${post.mediaBytes}`;
      headers["Content-Length"] = String(end - start + 1);
    }
    let position = start;
    const store = mediaStore();
    const stream = new ReadableStream<Uint8Array>({
      async pull(controller) {
        try {
          const part = Math.floor(position / PART_BYTES);
          const bytes = await store.get(`media/${id}/${part}`, { type: "arrayBuffer" });
          if (!bytes) throw new Error("Missing media");
          const offset = position % PART_BYTES;
          const length = Math.min(bytes.byteLength - offset, end - position + 1);
          if (length <= 0) throw new Error("Incomplete media");
          controller.enqueue(new Uint8Array(bytes, offset, length));
          position += length;
          if (position > end) controller.close();
        } catch { controller.error(new Error("This media is temporarily unavailable.")); }
      },
    });
    return new Response(stream, { status: range ? 206 : 200, headers });
  } catch (error) { return failure(error); }
};

export const config: Config = { path: "/api/media/:id" };
