import { randomUUID } from "node:crypto";
import type { Config, Context } from "@netlify/functions";
import { desc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { pinboardUpdates } from "../../db/schema.js";
import { authorName, failure, HttpError, json, readJson, requireUser, sameOrigin, text, UUID_PATTERN } from "../lib/http.js";

const publicUpdate = (update: typeof pinboardUpdates.$inferSelect) => ({
  id: update.id, ownerId: update.ownerId, authorName: update.authorName,
  tag: update.tag, title: update.title, body: update.body, createdAt: update.createdAt,
});

export default async (request: Request, context: Context) => {
  try {
    if (request.method === "GET") {
      const rows = await db.select().from(pinboardUpdates).orderBy(desc(pinboardUpdates.createdAt)).limit(30);
      return json({ updates: rows.map(publicUpdate) });
    }
    sameOrigin(request);
    const user = await requireUser();
    if (request.method === "POST" && !context.params.id) {
      const body = await readJson(request);
      const [update] = await db.insert(pinboardUpdates).values({
        id: randomUUID(), ownerId: user.id, authorName: authorName(user),
        title: text(body.title, "an update title", 80, true),
        tag: text(body.tag ?? "", "a tag", 24).toUpperCase(),
        body: text(body.body, "a short note", 240, true),
      }).returning();
      return json({ update: publicUpdate(update) }, 201);
    }
    if (request.method !== "DELETE") throw new HttpError(405, "Method not allowed.");
    const id = context.params.id;
    if (!id || !UUID_PATTERN.test(id)) throw new HttpError(404, "Update not found.");
    const [update] = await db.select().from(pinboardUpdates).where(eq(pinboardUpdates.id, id));
    if (!update) throw new HttpError(404, "Update not found.");
    if (update.ownerId !== user.id && !user.roles?.includes("admin")) throw new HttpError(403, "You can only unpin your own updates.");
    await db.delete(pinboardUpdates).where(eq(pinboardUpdates.id, id));
    return json({ ok: true });
  } catch (error) { return failure(error); }
};

export const config: Config = { path: ["/api/pinboard", "/api/pinboard/:id"], rateLimit: { windowSize: 60, windowLimit: 40, aggregateBy: "ip" } };
