CREATE TABLE "album_photos" (
	"slot" text PRIMARY KEY,
	"image_key" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
