# AGENTS.md

## Architecture
- No frontend framework: `index.html` + `style.css` + plain JS files, each an IIFE scoped to one feature.
  - `script.js` — nav, gallery filters, local-only guestbook/diary, quiz, photo booth (3-column strip, up to 6 photos, canvas download).
  - `album.js` — The Spotlight album cards (`data-photo-slot`), uploads to `/api/album`.
  - `front-page.js` — hero polaroid photo (album slot `hero`), Hoon's Weverse note (`/api/weverse-note`), shared pin board (`/api/pinboard`).
  - `community.js` — account dialog (Identity via `/api/account`), community posts; emits `fan-auth-change`. Any `[data-account-open]` element opens the sign-in dialog.
  - `playlist-maker.js`, `fanarts.js` — playlists and the fanart wall.
- Functions in `netlify/functions/*.mts`; shared helpers in `netlify/lib/http.ts` (`requireUser`, `sameOrigin`, `readJson`, `text`, `failure`).
- Data: Netlify Database via Drizzle (`db/schema.ts`); image bytes in Netlify Blobs (`album-images`, `community-media`).

## Conventions & decisions
- Album slots are fixed in `netlify/functions/album.mts`. Regular slots can be replaced by anyone; `hero` requires a signed-in fan.
- Weverse note is manually entered by signed-in fans (there is no Weverse API); the newest row is shown, earlier ones listed as history.
- Pin board updates are shared; only the author or an `admin` role can unpin.
- Guestbook and diary intentionally stay in localStorage.
- Every schema change needs a generated migration (`npx drizzle-kit generate --name ...`).
- Netlify Identity must be enabled on the site (run `node scripts/enable.cjs` from the netlify-identity skill). Without it every sign-in/join fails. Auth mutations run server-side in `account.mts`; `authMessage()` maps Identity errors to fan-friendly hints.
