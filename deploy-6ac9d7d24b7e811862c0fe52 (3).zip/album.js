(() => {
  const cards = [...document.querySelectorAll("[data-photo-slot]")];
  const albumStatus = document.querySelector("#albumStatus");
  const maxBytes = 3 * 1024 * 1024;
  const supportedTypes = ["image/jpeg", "image/png", "image/webp"];

  function setStatus(card, message, isError = false) {
    const status = card.querySelector(".album-status");
    status.textContent = message;
    status.dataset.error = String(isError);
  }

  function showPhoto(card, url) {
    return new Promise((resolve, reject) => {
      const photo = new Image();
      photo.className = "album-photo";
      photo.alt = `Shared album photo: ${card.querySelector(":scope > p").textContent}`;
      photo.onload = () => {
        const container = card.querySelector(".gallery-image");
        container.querySelector(".album-photo")?.remove();
        container.append(photo);
        resolve();
      };
      photo.onerror = () => reject(new Error("Photo is saved, but its preview could not load. Reload to try again."));
      photo.src = url;
    });
  }

  cards.forEach(card => {
    const button = card.querySelector(".album-choose");
    const input = card.querySelector(".album-upload");
    button.disabled = true;
    button.addEventListener("click", () => input.click());
    input.addEventListener("change", async () => {
      const file = input.files[0];
      input.value = "";
      if (!file) return;
      if (!supportedTypes.includes(file.type)) {
        setStatus(card, "Please choose a JPG, PNG or WebP photo.", true);
        return;
      }
      if (!file.size || file.size > maxBytes) {
        setStatus(card, "Choose a photo smaller than 3 MB (and not an empty file).", true);
        return;
      }
      button.disabled = true;
      button.textContent = "saving photo…";
      card.setAttribute("aria-busy", "true");
      setStatus(card, "Uploading to the shared album…");
      try {
        const response = await fetch(`/api/album?slot=${encodeURIComponent(card.dataset.photoSlot)}`, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || "Couldn't save this photo. Please try again.");
        await showPhoto(card, result.url);
        setStatus(card, "Saved for everyone to see.");
        button.textContent = "change photo";
      } catch (error) {
        setStatus(card, error.message || "Couldn't save this photo. Please try again.", true);
      } finally {
        button.disabled = false;
        card.removeAttribute("aria-busy");
        button.textContent = card.querySelector(".album-photo") ? "change photo" : "choose photo";
      }
    });
  });

  async function loadAlbum() {
    albumStatus.textContent = "Loading saved photos…";
    try {
      const response = await fetch("/api/album", { cache: "no-store" });
      if (!response.ok) throw new Error("Album unavailable");
      const photos = await response.json();
      await Promise.all(cards.map(async card => {
        const saved = photos.find(photo => photo.slot === card.dataset.photoSlot);
        if (!saved) return;
        try {
          await showPhoto(card, saved.url);
          card.querySelector(".album-choose").textContent = "change photo";
        } catch (error) {
          setStatus(card, error.message, true);
        }
      }));
      albumStatus.textContent = "";
    } catch {
      albumStatus.textContent = "Saved photos couldn't load. Reload to try again; your saved photos have not been removed.";
    } finally {
      cards.forEach(card => { card.querySelector(".album-choose").disabled = false; });
    }
  }

  loadAlbum();
})();
