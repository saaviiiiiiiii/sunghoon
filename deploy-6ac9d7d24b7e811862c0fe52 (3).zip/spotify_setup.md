# Activate the Spotify playlist maker

Gallery photos, credited fanart, and fancam videos use Netlify storage and do not require Spotify configuration. New posts require a fan account; Netlify Identity was enabled for this site. People can sign up with a public nickname, confirm their email, and sign in. Visitors can remove their own posts, and accounts with the Identity `admin` role can remove community posts.

The in-site Spotify maker is implemented but deliberately remains inactive until a site owner supplies its configuration. It does not claim to create or save playlists while Spotify is unavailable. It uses the authorization-code flow with PKCE, searches Spotify tracks, creates a public playlist in the connected user's account, and saves a shared playlist post only after the tracks have been added successfully.

## Developer app

Create a Web API app in the Spotify Developer Dashboard. Register this exact redirect URI:

```text
https://ilovesunghoon.netlify.app/api/spotify/callback
```

Follow the current eligibility rules displayed in Spotify's dashboard. Development-mode apps require an eligible app owner and are limited to an allowlist of users; add each permitted Spotify account before they connect. A publicly reachable site does not automatically make a development-mode Spotify app available to every visitor. Broader access requires the appropriate Spotify approval.

## Netlify environment variables

Set the following variables in Netlify Project configuration, with the Functions runtime scope, then deploy the site again:

- `SPOTIFY_CLIENT_ID`: the app's client ID.
- `SPOTIFY_REDIRECT_URI`: the exact redirect URI registered above.
- `SPOTIFY_TOKEN_ENCRYPTION_KEY`: a securely generated, base64-encoded 32-byte key. Generate and store it with a password manager or another secure secret-management tool. Do not commit it, paste it into chat, or share it with visitors.

PKCE does not require a Spotify client secret. Access and refresh tokens stay server-side, encrypted with AES-256-GCM in Netlify Database. Keep the encryption key stable across deployments. If the key changes, existing connections cannot be read and users must reconnect Spotify.

The configured redirect URI must have the same origin as the site serving the maker. A production configuration intentionally does not activate Spotify account connections on a different deploy-preview URL. A separate app configuration and registered callback are needed to test a preview.

## Check activation

1. Sign into a fan account on the deployed site.
2. Open the playlist section and choose **connect Spotify**.
3. Approve playlist modification on Spotify's permission screen.
4. Search for songs, add and arrange tracks, and provide a playlist name.
5. Confirm public sharing and choose **create & share playlist**.
6. Check the playlist on Spotify and the shared post after reloading this site.

The maker supports up to 50 tracks per draft and links every search result back to Spotify. Creation references prevent an unchanged retry from creating an extra playlist after a successful response or a track-adding failure. If Spotify times out before returning a new playlist ID, the maker does not blindly retry creation; check the connected Spotify account before starting a new draft.

Disconnecting removes this site's stored Spotify connection. Removing a playlist post hides it from this site's shared collection without deleting the playlist from Spotify. Access can also be revoked in the Spotify account's connected-app settings.

## Uploads and deployment

Photos accept JPG, PNG, and WebP up to 3 MB. Fanart requires visible artist credit. Pictures are validated and re-encoded as WebP without their original embedded metadata. Fancams accept MP4 and WebM up to 15 MB. For broad browser playback, prefer MP4 with H.264/AAC or WebM with VP8/VP9. Videos are not transcoded. Files are sent in parts of at most 3 MB, stored in Netlify Blobs, and served with byte-range support for seeking.

Permission to share is required before publishing. Posts, upload records, and playlist records persist in Netlify Database. Database migrations are included in `netlify/database/migrations` and are applied on deployment. An hourly scheduled function removes abandoned upload files after 24 hours. Existing photo-album replacement controls retain their original shared editing behavior; the new posting forms add separate posts instead of replacing existing cards.

Identity email confirmation and recovery links return to the site and are handled by the account dialog. Registration and email-delivery settings can be managed in Netlify Project configuration. No Spotify credentials are needed to deploy or use the media-posting features.
