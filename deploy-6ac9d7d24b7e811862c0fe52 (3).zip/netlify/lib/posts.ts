import { getStore } from "@netlify/blobs";
import type { communityPosts } from "../../db/schema.js";

export const mediaStore = () => getStore({ name: "community-media", consistency: "strong" });

export function publicPost(post: typeof communityPosts.$inferSelect) {
  return {
    id: post.id, ownerId: post.ownerId, authorName: post.authorName, kind: post.kind,
    title: post.title, caption: post.caption, category: post.category, artistCredit: post.artistCredit,
    url: `/api/media/${post.id}`, createdAt: post.createdAt,
  };
}

export async function removeParts(prefix: string, count: number) {
  const store = mediaStore();
  await Promise.all(Array.from({ length: count }, (_, part) => store.delete(`${prefix}/${part}`)));
}
