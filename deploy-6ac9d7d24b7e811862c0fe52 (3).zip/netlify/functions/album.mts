import { randomUUID } from "node:crypto";
import type { Config, Context } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { eq } from "drizzle-orm";
import sharp from "sharp";
import { db } from "../../db/index.js";
import { albumPhotos } from "../../db/schema.js";
import { currentUser, isSameSite } from "../lib/http.js";

const slots = ["spotlight", "soft", "winter", "performance", "hero"];
// The front-page polaroid is only changeable by signed-in fans.
const signedInSlots = ["hero"];
const imageTypes = new Map([
  ["image/jpeg", "jpeg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);
const maxBytes = 3 * 1024 * 1024;

function json(value: unknown, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store" } });
}

export default async (request: Request, context: Context) => {
  const imageKey = context.params.id;
  if (request.method !== "GET" && (request.method !== "POST" || imageKey)) {
    return new Response("Method not allowed", { status: 405, headers: { Allow: imageKey ? "GET" : "GET, POST" } });
  }
  try {
    if (request.method === "GET") {
      if (imageKey) {
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(imageKey)) {
          return json({ error: "Photo not found." }, 404);
        }
        const image = await getStore({ name: "album-images", consistency: "strong" }).get(imageKey, { type: "arrayBuffer" });
        if (!image) return json({ error: "Photo not found." }, 404);
        return new Response(image, {
          headers: {
            "Content-Type": "image/webp",
            "Cache-Control": "public, max-age=31536000, immutable",
            "X-Content-Type-Options": "nosniff",
          },
        });
      }
      const photos = await db.select().from(albumPhotos);
      return json(photos.map(photo => ({ slot: photo.slot, url: `/api/album/photos/${photo.imageKey}` })));
    }

    const url = new URL(request.url);
    if (!isSameSite(request)) {
      return json({ error: "Please upload from this site's photo album." }, 403);
    }
    const slot = url.searchParams.get("slot");
    if (!slot || !slots.includes(slot)) return json({ error: "Choose a valid album card." }, 400);
    if (signedInSlots.includes(slot) && !(await currentUser().catch(() => null))) {
      return json({ error: "Sign in to change the front-page photo." }, 401);
    }
    const contentType = request.headers.get("content-type") || "";
    if (!imageTypes.has(contentType)) return json({ error: "Please choose a JPG, PNG or WebP photo." }, 415);
    if (Number(request.headers.get("content-length")) > maxBytes) return json({ error: "Photos must be smaller than 3 MB." }, 413);
    if (!request.body) return json({ error: "Choose a photo first." }, 400);

    const reader = request.body.getReader();
    const chunks: Uint8Array[] = [];
    let totalBytes = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      totalBytes += value.byteLength;
      if (totalBytes > maxBytes) {
        await reader.cancel();
        return json({ error: "Photos must be smaller than 3 MB." }, 413);
      }
      chunks.push(value);
    }
    if (!totalBytes) return json({ error: "Choose a photo first." }, 400);
    let photo: Buffer;
    try {
      const image = sharp(Buffer.concat(chunks), { limitInputPixels: 40000000, animated: false });
      const metadata = await image.metadata();
      if (metadata.format !== imageTypes.get(contentType)) return json({ error: "The file doesn't match its image type." }, 415);
      photo = await image.rotate().resize({ width: 2000, height: 2000, fit: "inside", withoutEnlargement: true }).webp({ quality: 85 }).toBuffer();
    } catch {
      return json({ error: "This photo couldn't be read. Try another JPG, PNG or WebP." }, 400);
    }

    const store = getStore({ name: "album-images", consistency: "strong" });
    const [previous] = await db.select().from(albumPhotos).where(eq(albumPhotos.slot, slot));
    const newKey = randomUUID();
    await store.set(newKey, new Uint8Array(photo).buffer);
    try {
      await db.insert(albumPhotos).values({ slot, imageKey: newKey }).onConflictDoUpdate({
        target: albumPhotos.slot,
        set: { imageKey: newKey, updatedAt: new Date() },
      });
    } catch (error) {
      await store.delete(newKey).catch(() => {});
      throw error;
    }
    if (previous) await store.delete(previous.imageKey).catch(() => {});
    return json({ slot, url: `/api/album/photos/${newKey}` });
  } catch {
    return json({ error: "The shared album is temporarily unavailable. Please try again." }, 503);
  }
};

export const config: Config = {
  path: ["/api/album", "/api/album/photos/:id"],
  rateLimit: { windowSize: 60, windowLimit: 60, aggregateBy: "ip" },
};
