import { getUser, refreshSession } from "@netlify/identity";

export const PART_BYTES = 3 * 1024 * 1024;
export const PHOTO_BYTES = PART_BYTES;
export const VIDEO_BYTES = 15 * 1024 * 1024;
export const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export function json(value: unknown, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store" } });
}

export function failure(error: unknown) {
  return error instanceof HttpError
    ? json({ error: error.message }, error.status)
    : json({ error: "This service is temporarily unavailable. Please try again." }, 503);
}

// Accept requests from this site's own pages. Compares hosts rather than full origins, because the
// function can see the request as http:// or under a different host header than the visitor's https:// page.
export function isSameSite(request: Request) {
  const fetchSite = request.headers.get("sec-fetch-site");
  if (fetchSite === "same-origin") return true;
  if (fetchSite === "cross-site") return false;
  const origin = request.headers.get("origin");
  if (!origin) return fetchSite === null || fetchSite === "none";
  let originHost;
  try { originHost = new URL(origin).host; } catch { return false; }
  const hosts = [new URL(request.url).host, request.headers.get("host"), request.headers.get("x-forwarded-host")];
  return hosts.some(host => host && host.split(",")[0].trim() === originHost);
}

export function sameOrigin(request: Request) {
  if (!isSameSite(request)) throw new HttpError(403, "Please post from this site's own pages, then try again.");
}

export async function currentUser() {
  await refreshSession().catch(() => null);
  return getUser();
}

export async function requireUser() {
  const user = await currentUser();
  if (!user) throw new HttpError(401, "Sign in to post or make a playlist.");
  return user;
}

export function authorName(user: Awaited<ReturnType<typeof requireUser>>) {
  return (user.name || "ENGENE").slice(0, 40);
}

export async function readBytes(request: Request, limit: number) {
  if (Number(request.headers.get("content-length")) > limit) throw new HttpError(413, "This upload is too large.");
  if (!request.body) throw new HttpError(400, "No content was received.");
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > limit) {
      await reader.cancel();
      throw new HttpError(413, "This upload is too large.");
    }
    chunks.push(value);
  }
  if (!size) throw new HttpError(400, "No content was received.");
  return Buffer.concat(chunks);
}

export async function readJson(request: Request): Promise<Record<string, unknown>> {
  if (!request.headers.get("content-type")?.startsWith("application/json")) throw new HttpError(415, "Expected form data in JSON format.");
  try {
    const value = JSON.parse((await readBytes(request, 12000)).toString("utf8"));
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
    return value;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(400, "The submitted form could not be read.");
  }
}

export function text(value: unknown, label: string, max: number, required = false) {
  if (typeof value !== "string") throw new HttpError(400, `Enter ${label}.`);
  const trimmed = value.trim();
  if (trimmed.length > max || (required && !trimmed)) throw new HttpError(400, `Check ${label} (up to ${max} characters).`);
  return trimmed;
}

export function passwordText(value: unknown) {
  if (typeof value !== "string" || !value || value.length > 256) throw new HttpError(400, "Enter a password of up to 256 characters.");
  return value;
}
