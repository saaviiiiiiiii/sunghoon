import type { Config } from "@netlify/functions";
import { eq, lt } from "drizzle-orm";
import { db } from "../../db/index.js";
import { communityPosts, communityUploads, spotifyStates } from "../../db/schema.js";
import { removeParts } from "../lib/posts.js";

export default async () => {
  const cutoff = new Date(Date.now() - 86400000);
  const expired = await db.select().from(communityUploads).where(lt(communityUploads.createdAt, cutoff)).limit(100);
  for (const upload of expired) {
    await removeParts(`uploads/${upload.id}`, upload.partCount);
    const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, upload.id));
    if (!post) await removeParts(`media/${upload.id}`, upload.partCount);
    await db.delete(communityUploads).where(eq(communityUploads.id, upload.id));
  }
  await db.delete(spotifyStates).where(lt(spotifyStates.expiresAt, new Date()));
};

export const config: Config = { schedule: "17 * * * *" };
