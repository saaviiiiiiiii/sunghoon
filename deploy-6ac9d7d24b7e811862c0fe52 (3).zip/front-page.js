// Front page: fan photo on the hero polaroid, Hoon's Weverse note, and the shared pin board.
(() => {
  const PHOTO_BYTES = 3 * 1024 * 1024;
  const PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
  let user = null;

  function element(tag, className, content) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (content !== undefined) node.textContent = content;
    return node;
  }

  function status(node, message, isError = false) {
    node.textContent = message;
    node.dataset.error = String(isError);
  }

  async function api(url, options = {}) {
    const { json: body, ...rest } = options;
    let response;
    try {
      response = await fetch(url, {
        cache: "no-store", ...rest,
        ...(body !== undefined ? { headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {}),
      });
    } catch { throw new Error("Connection interrupted. Please try again."); }
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || "This action couldn't finish. Please try again.");
    return result;
  }

  const formatDay = value => {
    const date = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T12:00:00`) : new Date(value);
    return Number.isNaN(date.getTime()) ? "" : date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  };

  const openSignIn = trigger => (trigger || document.querySelector("[data-account-open]"))?.click();

  // Hero polaroid photo
  const polaroid = document.querySelector("[data-hero-photo]");
  const heroPhoto = polaroid.querySelector(".hero-photo");
  const heroChoose = polaroid.querySelector("[data-hero-choose]");
  const heroInput = polaroid.querySelector("[data-hero-input]");
  const heroStatus = polaroid.querySelector("[data-hero-status]");

  function showHeroPhoto(url) {
    return new Promise((resolve, reject) => {
      const photo = new Image();
      photo.className = "album-photo";
      photo.alt = "A fan's photo for our ice prince";
      photo.onload = () => {
        heroPhoto.querySelector(".album-photo")?.remove();
        heroPhoto.append(photo);
        heroPhoto.classList.add("has-photo");
        heroPhoto.setAttribute("aria-label", photo.alt);
        heroChoose.textContent = "change photo ✦";
        resolve();
      };
      photo.onerror = () => reject(new Error("The photo is saved but couldn't load. Reload to try again."));
      photo.src = url;
    });
  }

  heroChoose.addEventListener("click", () => {
    if (!user) {
      status(heroStatus, "Sign in to add your photo here ♡");
      openSignIn();
      return;
    }
    heroInput.click();
  });
  heroInput.addEventListener("change", async () => {
    const file = heroInput.files[0];
    heroInput.value = "";
    if (!file) return;
    if (!PHOTO_TYPES.includes(file.type)) return status(heroStatus, "Please choose a JPG, PNG or WebP photo.", true);
    if (!file.size || file.size > PHOTO_BYTES) return status(heroStatus, "Choose a photo smaller than 3 MB.", true);
    heroChoose.disabled = true;
    status(heroStatus, "Saving your photo…");
    try {
      const result = await api("/api/album?slot=hero", { method: "POST", headers: { "Content-Type": file.type }, body: file });
      await showHeroPhoto(result.url);
      status(heroStatus, "Saved to the front page ♡");
    } catch (error) {
      status(heroStatus, error.message, true);
    } finally {
      heroChoose.disabled = false;
    }
  });

  async function loadHeroPhoto() {
    try {
      const photos = await api("/api/album");
      const hero = photos.find(photo => photo.slot === "hero");
      if (hero) await showHeroPhoto(hero.url);
    } catch { /* keep the illustrated placeholder */ }
  }

  // Hoon's Weverse note
  const noteBody = document.querySelector("[data-weverse-body]");
  const noteDate = document.querySelector("[data-weverse-date]");
  const noteDialog = document.querySelector("#weverseDialog");
  const noteForm = noteDialog.querySelector("[data-weverse-form]");
  const noteStatus = noteDialog.querySelector("[data-weverse-status]");
  const noteHistory = noteDialog.querySelector("[data-weverse-history]");
  const noteTrigger = document.querySelector("[data-weverse-open]");

  function renderNotes(notes) {
    const [latest] = notes;
    if (latest) {
      noteBody.textContent = latest.body;
      const day = formatDay(latest.postedOn || latest.createdAt);
      noteDate.textContent = day ? `· ${day}` : "";
      noteDate.dateTime = latest.postedOn || latest.createdAt;
    }
    noteHistory.replaceChildren();
    const earlier = notes.slice(1);
    if (!earlier.length) return;
    noteHistory.append(element("h3", "", "earlier notes from hoon"));
    earlier.forEach(note => {
      const item = element("article");
      const day = formatDay(note.postedOn || note.createdAt);
      item.append(element("p", "", note.body), element("small", "", `${day ? `${day} · ` : ""}shared by ${note.authorName}`));
      noteHistory.append(item);
    });
  }

  async function loadNotes() {
    try { renderNotes((await api("/api/weverse-note")).notes); }
    catch { /* keep the default note */ }
  }

  noteTrigger.addEventListener("click", () => {
    status(noteStatus, user ? "" : "Sign in first so we know who updated the note.");
    noteForm.querySelector("[type=submit]").textContent = user ? "pin his note ♡" : "sign in to update";
    noteDialog.showModal();
  });
  noteDialog.querySelector("[data-weverse-close]").addEventListener("click", () => noteDialog.close());
  noteDialog.addEventListener("close", () => noteTrigger.focus());
  noteForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
      noteDialog.close();
      openSignIn();
      return;
    }
    const submit = noteForm.querySelector("[type=submit]");
    submit.disabled = true;
    status(noteStatus, "Pinning his note…");
    try {
      await api("/api/weverse-note", { method: "POST", json: { body: noteForm.elements.body.value, postedOn: noteForm.elements.postedOn.value } });
      noteForm.reset();
      await loadNotes();
      status(noteStatus, "Updated for everyone ♡");
    } catch (error) {
      status(noteStatus, error.message, true);
    } finally {
      submit.disabled = false;
    }
  });

  // Shared pin board
  const updatesList = document.querySelector("#updatesList");
  const updateForm = document.querySelector("#updateForm");
  const pinStatus = document.querySelector("[data-pin-status]");
  const pinSignIn = document.querySelector("[data-pin-signin]");
  const pinDefault = pinStatus.textContent;

  function renderUpdate(update) {
    const item = element("article", "update-item custom-update");
    item.append(element("span", "update-icon", "📎"));
    const content = element("div");
    const day = formatDay(update.createdAt);
    content.append(
      element("span", "update-tag", update.tag || "FAN NOTE"),
      element("h3", "", update.title),
      element("p", "", update.body),
      element("span", "update-meta", `pinned by ${update.authorName}${day ? ` · ${day}` : ""}`),
    );
    if (user && (user.id === update.ownerId || user.admin)) {
      const unpin = element("button", "unpin", "unpin ×");
      unpin.type = "button";
      unpin.addEventListener("click", async () => {
        unpin.disabled = true;
        try {
          await api(`/api/pinboard/${update.id}`, { method: "DELETE" });
          item.remove();
        } catch (error) {
          status(pinStatus, error.message, true);
          unpin.disabled = false;
        }
      });
      content.append(unpin);
    }
    item.append(content);
    return item;
  }

  async function loadUpdates() {
    try {
      const { updates } = await api("/api/pinboard");
      updatesList.querySelectorAll(".custom-update").forEach(node => node.remove());
      updatesList.prepend(...updates.map(renderUpdate));
    } catch {
      status(pinStatus, "Pinned updates couldn't load right now. Reload to try again.", true);
    }
  }

  updateForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
      status(pinStatus, "Sign in to pin an update for everyone ♡", true);
      pinSignIn.hidden = false;
      return;
    }
    const submit = updateForm.querySelector("[type=submit]");
    submit.disabled = true;
    status(pinStatus, "Pinning to the board…");
    try {
      const { update } = await api("/api/pinboard", { method: "POST", json: {
        title: updateForm.querySelector("#updateTitle").value,
        tag: updateForm.querySelector("#updateTag").value,
        body: updateForm.querySelector("#updateBody").value,
      } });
      updateForm.reset();
      updatesList.prepend(renderUpdate(update));
      status(pinStatus, "Pinned and saved for everyone ♡");
    } catch (error) {
      status(pinStatus, error.message, true);
    } finally {
      submit.disabled = false;
    }
  });

  async function start() {
    try { user = (await api("/api/account")).user; } catch { user = null; }
    if (!user) pinSignIn.hidden = false;
    else status(pinStatus, pinDefault.replace("Sign in to pin one, and verify", "Verify"));
    loadHeroPhoto();
    loadNotes();
    loadUpdates();
  }

  start();
})();
