import { createHash, randomUUID } from "node:crypto";
import type { Config, Context } from "@netlify/functions";
import { and, count, eq, gt } from "drizzle-orm";
import sharp from "sharp";
import { db } from "../../db/index.js";
import { communityPosts, communityUploads } from "../../db/schema.js";
import { authorName, currentUser, failure, HttpError, json, PART_BYTES, PHOTO_BYTES, readBytes, readJson, sameOrigin, text, UUID_PATTERN, VIDEO_BYTES } from "../lib/http.js";
import { mediaStore, publicPost, removeParts } from "../lib/posts.js";

const kinds = ["gallery", "fanart", "fancam"];
const photoTypes = new Map([["image/jpeg", "jpeg"], ["image/png", "png"], ["image/webp", "webp"]]);
// Spotlight gallery photos can be posted without an account; guests are tracked by a hashed IP for rate limits.
const guestKinds = ["gallery"];

async function poster(context: Context) {
  const user = await currentUser().catch(() => null);
  if (user) return { id: user.id, name: authorName(user), guest: false };
  return { id: `guest:${createHash("sha256").update(context.ip || "unknown").digest("hex").slice(0, 32)}`, name: "", guest: true };
}

export default async (request: Request, context: Context) => {
  try {
    if (request.method !== "POST") throw new HttpError(405, "Method not allowed.");
    sameOrigin(request);
    const user = await poster(context);
    const { id, part } = context.params;
    if (!id) {
      const body = await readJson(request);
      const kind = text(body.kind, "a post type", 10, true);
      if (!kinds.includes(kind)) throw new HttpError(400, "Choose gallery, fanart or fancam.");
      if (user.guest && !guestKinds.includes(kind)) throw new HttpError(401, "Sign in to post fanart or fancams. Spotlight photos can be posted without an account.");
      const contentType = text(body.contentType, "a file type", 30, true);
      const video = kind === "fancam";
      if (video ? !["video/mp4", "video/webm"].includes(contentType) : !photoTypes.has(contentType)) {
        throw new HttpError(415, video ? "Choose an MP4 or WebM video." : "Choose a JPG, PNG or WebP photo.");
      }
      const sourceBytes = Number(body.size);
      if (!Number.isSafeInteger(sourceBytes) || sourceBytes < 1 || sourceBytes > (video ? VIDEO_BYTES : PHOTO_BYTES)) {
        throw new HttpError(413, video ? "Videos must be 15 MB or smaller." : "Photos must be 3 MB or smaller.");
      }
      if (body.permission !== true) throw new HttpError(400, "Confirm that you have permission to share this file.");
      const category = text(body.category, "a theme", 10, true);
      if (!["stage", "soft", "winter"].includes(category)) throw new HttpError(400, "Choose a valid theme.");
      const artistCredit = text(body.artistCredit ?? "", "artist credit", 100, kind === "fanart");
      const [pending] = await db.select({ total: count() }).from(communityUploads).where(and(
        eq(communityUploads.ownerId, user.id), gt(communityUploads.createdAt, new Date(Date.now() - 3600000)),
      ));
      if (pending.total >= 20) throw new HttpError(429, "You've started many uploads recently. Please try again in an hour.");
      const uploadId = randomUUID();
      await db.insert(communityUploads).values({
        id: uploadId, ownerId: user.id, authorName: user.guest ? text(body.guestName ?? "", "a nickname", 40) || "guest ENGENE" : user.name, kind, contentType, sourceBytes,
        title: text(body.title, "a title", 80, true), caption: text(body.caption, "a caption", 500),
        category, artistCredit, partCount: Math.ceil(sourceBytes / PART_BYTES),
      });
      return json({ id: uploadId, partBytes: PART_BYTES }, 201);
    }
    if (!UUID_PATTERN.test(id)) throw new HttpError(404, "Upload not found.");
    const [upload] = await db.select().from(communityUploads).where(and(eq(communityUploads.id, id), eq(communityUploads.ownerId, user.id)));
    if (!upload) throw new HttpError(404, "Upload not found.");
    const [existing] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
    if (existing) return json({ post: publicPost(existing), published: true });
    if (upload.createdAt.getTime() < Date.now() - 3600000) throw new HttpError(410, "This upload expired. Choose the file again to start a new upload.");
    const store = mediaStore();
    if (part !== undefined) {
      const partNumber = Number(part);
      if (!/^\d+$/.test(part) || !Number.isInteger(partNumber) || partNumber < 0 || partNumber >= upload.partCount) throw new HttpError(400, "Invalid upload part.");
      if (request.headers.get("content-type") !== "application/octet-stream") throw new HttpError(415, "Invalid upload data.");
      const bytes = await readBytes(request, PART_BYTES);
      const expectedBytes = Math.min(PART_BYTES, upload.sourceBytes - partNumber * PART_BYTES);
      if (bytes.byteLength !== expectedBytes) throw new HttpError(400, "An upload part was incomplete. Please retry.");
      await store.set(`uploads/${id}/${partNumber}`, new Uint8Array(bytes).buffer);
      return json({ ok: true });
    }
    const chunks: Buffer[] = [];
    for (let partNumber = 0; partNumber < upload.partCount; partNumber++) {
      const bytes = await store.get(`uploads/${id}/${partNumber}`, { type: "arrayBuffer" });
      if (!bytes || bytes.byteLength !== Math.min(PART_BYTES, upload.sourceBytes - partNumber * PART_BYTES)) throw new HttpError(400, "Some of the file is missing. Please retry the upload.");
      chunks.push(Buffer.from(bytes));
    }
    let contentType = upload.contentType;
    let mediaChunks = chunks;
    if (upload.kind !== "fancam") {
      try {
        const image = sharp(chunks[0], { limitInputPixels: 40000000 });
        const metadata = await image.metadata();
        if (metadata.format !== photoTypes.get(upload.contentType)) throw new Error();
        const encoded = await image.rotate().resize({ width: 2000, height: 2000, fit: "inside", withoutEnlargement: true }).webp({ quality: 85 }).toBuffer();
        if (encoded.byteLength > PART_BYTES) throw new Error();
        mediaChunks = [encoded];
        contentType = "image/webp";
      } catch {
        throw new HttpError(400, "This image couldn't be read. Try a different JPG, PNG or WebP.");
      }
    } else {
      const first = chunks[0];
      const mp4 = first.length >= 16 && first.subarray(4, 8).toString("ascii") === "ftyp";
      const webm = first.length >= 16 && first.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3])) && first.subarray(0, 4096).includes(Buffer.from("webm"));
      if (contentType === "video/mp4" ? !mp4 : !webm) throw new HttpError(400, "This file doesn't appear to be the selected video format.");
    }
    for (let partNumber = 0; partNumber < mediaChunks.length; partNumber++) {
      await store.set(`media/${id}/${partNumber}`, new Uint8Array(mediaChunks[partNumber]).buffer);
    }
    const [post] = await db.insert(communityPosts).values({
      id, ownerId: upload.ownerId, authorName: upload.authorName, kind: upload.kind, title: upload.title,
      caption: upload.caption, category: upload.category, artistCredit: upload.artistCredit,
      contentType, mediaBytes: mediaChunks.reduce((total, chunk) => total + chunk.length, 0), partCount: mediaChunks.length,
    }).onConflictDoNothing().returning();
    const result = post || (await db.select().from(communityPosts).where(eq(communityPosts.id, id)))[0];
    await removeParts(`uploads/${id}`, upload.partCount).catch(() => {});
    return json({ post: publicPost(result) }, 201);
  } catch (error) { return failure(error); }
};

export const config: Config = {
  path: ["/api/uploads", "/api/uploads/:id/parts/:part", "/api/uploads/:id/publish"],
  rateLimit: { windowSize: 60, windowLimit: 60, aggregateBy: "ip" },
};
