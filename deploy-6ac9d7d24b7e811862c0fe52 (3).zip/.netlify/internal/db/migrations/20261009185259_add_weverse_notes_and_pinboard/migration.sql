CREATE TABLE "pinboard_updates" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"author_name" text NOT NULL,
	"tag" text DEFAULT '' NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "weverse_notes" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"author_name" text NOT NULL,
	"body" text NOT NULL,
	"posted_on" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "pinboard_updates_created_idx" ON "pinboard_updates" ("created_at");--> statement-breakpoint
CREATE INDEX "weverse_notes_created_idx" ON "weverse_notes" ("created_at");