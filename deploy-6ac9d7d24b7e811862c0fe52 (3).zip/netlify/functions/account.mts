import type { Config } from "@netlify/functions";
import { AuthError, MissingIdentityError, confirmEmail, login, logout, recoverPassword, requestPasswordRecovery, signup } from "@netlify/identity";
import { currentUser, failure, HttpError, json, passwordText, readJson, sameOrigin, text } from "../lib/http.js";

export default async (request: Request) => {
  try {
    if (request.method === "GET") {
      const user = await currentUser();
      return json({ user: user ? { id: user.id, name: user.name || "ENGENE", admin: user.roles?.includes("admin") || false } : null });
    }
    if (request.method !== "POST") throw new HttpError(405, "Method not allowed.");
    sameOrigin(request);
    const body = await readJson(request);
    if (body.action === "logout") {
      await logout();
      return json({ ok: true });
    }
    if (body.action === "confirm") {
      await confirmEmail(text(body.token, "the confirmation link", 4096, true));
      return json({ ok: true });
    }
    if (body.action === "reset") {
      const password = passwordText(body.password);
      if (password.length < 8) throw new HttpError(400, "Use a password of at least 8 characters.");
      await recoverPassword(text(body.token, "the recovery link", 4096, true), password);
      return json({ ok: true });
    }
    const email = text(body.email, "your email", 254, true);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, "Enter a valid email address.");
    if (body.action === "recover") {
      await requestPasswordRecovery(email);
      return json({ message: "If an account matches, a password reset link is on its way." });
    }
    const password = passwordText(body.password);
    if (body.action === "signup") {
      if (password.length < 8) throw new HttpError(400, "Use a password of at least 8 characters.");
      const user = await signup(email, password, { full_name: text(body.name, "a public nickname", 40, true) });
      return json({ ok: Boolean(user.confirmedAt), message: user.confirmedAt ? "Account created." : "Check your email to confirm your account, then sign in." });
    }
    if (body.action !== "login") throw new HttpError(400, "Choose an account action.");
    await login(email, password);
    return json({ ok: true });
  } catch (error) {
    if (error instanceof MissingIdentityError) return json({ error: "Fan accounts aren't switched on yet. Please try again in a little while." }, 503);
    if (error instanceof AuthError) return json({ error: authMessage(error) }, error.status === 401 ? 401 : 400);
    return failure(error);
  }
};

// Turn Identity errors into a hint the fan can act on, without revealing whether an email is registered.
function authMessage(error: AuthError) {
  const detail = error.message.toLowerCase();
  if (detail.includes("not confirmed")) return "Please confirm your email first — check your inbox (and spam) for the link, then sign in.";
  if (detail.includes("already") && detail.includes("registered")) return "That email already has an account. Sign in instead, or use “forgot password”.";
  if (detail.includes("expired") || detail.includes("invalid token") || detail.includes("not found")) return "This link has expired or was already used. Request a fresh one and try again.";
  if (error.status === 401 || detail.includes("invalid")) return "That email and password don't match. Check them and try again.";
  if (error.status === 403) return "New sign-ups are closed right now.";
  if (error.status === 422) return "Check your email and password (at least 8 characters) and try again.";
  if (error.status === 429) return "Too many tries. Please wait a minute and try again.";
  return "Account action failed. Please try again in a moment.";
}

export const config: Config = { path: "/api/account", rateLimit: { windowSize: 60, windowLimit: 20, aggregateBy: "ip" } };
