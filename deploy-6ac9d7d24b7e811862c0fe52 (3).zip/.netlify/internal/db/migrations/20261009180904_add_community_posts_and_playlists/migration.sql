CREATE TABLE "community_posts" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"author_name" text NOT NULL,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"caption" text NOT NULL,
	"category" text NOT NULL,
	"artist_credit" text DEFAULT '' NOT NULL,
	"content_type" text NOT NULL,
	"media_bytes" integer NOT NULL,
	"part_count" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "community_uploads" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"author_name" text NOT NULL,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"caption" text NOT NULL,
	"category" text NOT NULL,
	"artist_credit" text NOT NULL,
	"content_type" text NOT NULL,
	"source_bytes" integer NOT NULL,
	"part_count" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "shared_playlists" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"author_name" text NOT NULL,
	"title" text NOT NULL,
	"description" text NOT NULL,
	"track_uris" jsonb NOT NULL,
	"spotify_id" text,
	"status" text DEFAULT 'draft' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "spotify_connections" (
	"owner_id" text PRIMARY KEY,
	"access_token" text NOT NULL,
	"refresh_token" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "spotify_states" (
	"id" text PRIMARY KEY,
	"owner_id" text NOT NULL,
	"verifier" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE INDEX "community_posts_kind_created_idx" ON "community_posts" ("kind","created_at");--> statement-breakpoint
CREATE INDEX "community_uploads_owner_created_idx" ON "community_uploads" ("owner_id","created_at");--> statement-breakpoint
CREATE INDEX "shared_playlists_status_created_idx" ON "shared_playlists" ("status","created_at");