import { createHash, randomBytes } from "node:crypto";
import type { Config, Context } from "@netlify/functions";
import { and, desc, eq, gt, isNotNull, lt, or } from "drizzle-orm";
import { db } from "../../db/index.js";
import { sharedPlaylists, spotifyConnections, spotifyStates } from "../../db/schema.js";
import { authorName, currentUser, failure, HttpError, json, readJson, requireUser, sameOrigin, text, UUID_PATTERN } from "../lib/http.js";
import { decrypt, encrypt, requireSpotifySettings, saveConnection, spotifyRequest, spotifySettings, tokenRequest } from "../lib/spotify.js";

const hash = (value: string) => createHash("sha256").update(value).digest("base64url");
const cookieName = "spotify_state";
const spotifyIdPattern = /^[A-Za-z0-9]{22}$/;

function publicPlaylist(playlist: typeof sharedPlaylists.$inferSelect) {
  return {
    id: playlist.id, ownerId: playlist.ownerId, authorName: playlist.authorName, title: playlist.title,
    description: playlist.description, trackCount: playlist.trackUris.length,
    url: `https://open.spotify.com/playlist/${playlist.spotifyId}`, createdAt: playlist.createdAt,
  };
}

export default async (request: Request, context: Context) => {
  const action = context.params.action;
  const url = new URL(request.url);
  if (action === "callback") {
    const cookie = `${cookieName}=; Path=/api/spotify; HttpOnly; SameSite=Lax; Secure; Max-Age=0`;
    let result = "failed";
    try {
      if (request.method !== "GET") throw new HttpError(405, "Method not allowed.");
      const settings = requireSpotifySettings();
      const state = url.searchParams.get("state") || "";
      const browserState = request.headers.get("cookie")?.split(";").map(value => value.trim()).find(value => value.startsWith(`${cookieName}=`))?.slice(cookieName.length + 1);
      if (!state || state !== browserState || url.searchParams.has("error")) throw new HttpError(400, "Connection not approved.");
      const [pending] = await db.delete(spotifyStates).where(and(eq(spotifyStates.id, hash(state)), gt(spotifyStates.expiresAt, new Date()))).returning();
      const user = await requireUser();
      if (!pending || pending.ownerId !== user.id) throw new HttpError(400, "Connection expired.");
      const code = url.searchParams.get("code");
      if (!code) throw new HttpError(400, "Connection was incomplete.");
      const tokens = await tokenRequest({ grant_type: "authorization_code", code, redirect_uri: settings.redirectUri, code_verifier: decrypt(pending.verifier) });
      await saveConnection(user.id, tokens);
      result = "connected";
    } catch {}
    return new Response(null, { status: 303, headers: { Location: `/index.html?spotify=${result}#playlists`, "Set-Cookie": cookie, "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
  }
  try {
    if (action === "playlists" && request.method === "GET") {
      const cursor = url.searchParams.get("cursor");
      let cursorCondition;
      if (cursor) {
        if (!UUID_PATTERN.test(cursor)) throw new HttpError(400, "Invalid page marker.");
        const [anchor] = await db.select().from(sharedPlaylists).where(and(eq(sharedPlaylists.id, cursor), eq(sharedPlaylists.status, "published")));
        if (!anchor) throw new HttpError(400, "The collection changed. Refresh to continue.");
        cursorCondition = or(lt(sharedPlaylists.createdAt, anchor.createdAt), and(eq(sharedPlaylists.createdAt, anchor.createdAt), lt(sharedPlaylists.id, anchor.id)));
      }
      const rows = await db.select().from(sharedPlaylists).where(and(eq(sharedPlaylists.status, "published"), cursorCondition)).orderBy(desc(sharedPlaylists.createdAt), desc(sharedPlaylists.id)).limit(13);
      return json({ playlists: rows.slice(0, 12).map(publicPlaylist), nextCursor: rows.length > 12 ? rows[11].id : null });
    }
    if (action === "status" && request.method === "GET") {
      const settings = spotifySettings();
      const configured = Boolean(settings && new URL(settings.redirectUri).origin === url.origin);
      const user = await currentUser();
      const [connection] = user && configured ? await db.select({ ownerId: spotifyConnections.ownerId }).from(spotifyConnections).where(eq(spotifyConnections.ownerId, user.id)) : [];
      return json({ configured, connected: Boolean(connection) });
    }
    if (!["GET", "POST", "DELETE"].includes(request.method)) throw new HttpError(405, "Method not allowed.");
    if (request.method !== "GET") sameOrigin(request);
    const user = await requireUser();
    if (action === "playlists" && request.method === "DELETE") {
      const id = url.searchParams.get("id") || "";
      if (!UUID_PATTERN.test(id)) throw new HttpError(400, "Choose a valid playlist post.");
      const [playlist] = await db.select().from(sharedPlaylists).where(eq(sharedPlaylists.id, id));
      if (!playlist) throw new HttpError(404, "Playlist post not found.");
      if (playlist.ownerId !== user.id && !user.roles?.includes("admin")) throw new HttpError(403, "You can only remove your own playlist posts.");
      await db.update(sharedPlaylists).set({ status: "hidden", updatedAt: new Date() }).where(eq(sharedPlaylists.id, id));
      return json({ ok: true });
    }
    if (action === "disconnect" && request.method === "POST") {
      await db.delete(spotifyConnections).where(eq(spotifyConnections.ownerId, user.id));
      await db.delete(spotifyStates).where(eq(spotifyStates.ownerId, user.id));
      return json({ ok: true });
    }
    const settings = requireSpotifySettings();
    if (new URL(settings.redirectUri).origin !== url.origin) throw new HttpError(400, "Spotify connections are only available on the configured site address.");
    if (action === "connect" && request.method === "POST") {
      const state = randomBytes(32).toString("base64url");
      const verifier = randomBytes(64).toString("base64url");
      await db.delete(spotifyStates).where(eq(spotifyStates.ownerId, user.id));
      await db.insert(spotifyStates).values({ id: hash(state), ownerId: user.id, verifier: encrypt(verifier), expiresAt: new Date(Date.now() + 600000) });
      const parameters = new URLSearchParams({ client_id: settings.clientId, response_type: "code", redirect_uri: settings.redirectUri,
        scope: "playlist-modify-public playlist-modify-private", state, code_challenge_method: "S256", code_challenge: hash(verifier) });
      return new Response(JSON.stringify({ url: `https://accounts.spotify.com/authorize?${parameters}` }), {
        headers: { "Content-Type": "application/json", "Cache-Control": "no-store", "Set-Cookie": `${cookieName}=${state}; Path=/api/spotify; HttpOnly; SameSite=Lax; Secure; Max-Age=600` },
      });
    }
    if (action === "search" && request.method === "GET") {
      const query = text(url.searchParams.get("q"), "a song or artist", 100, true);
      const result = await spotifyRequest(user.id, `/search?${new URLSearchParams({ q: query, type: "track", limit: "10" })}`) as {
        tracks?: { items?: { id: string; uri: string; name: string; artists: { name: string }[] }[] };
      };
      const tracks = (result.tracks?.items || []).filter(track => track && spotifyIdPattern.test(track.id)).map(track => ({
        id: track.id, uri: track.uri, title: track.name, artist: track.artists.map(artist => artist.name).join(", "), url: `https://open.spotify.com/track/${track.id}`,
      }));
      return json({ tracks });
    }
    if (action !== "create" || request.method !== "POST") throw new HttpError(404, "Playlist action not found.");
    const body = await readJson(request);
    const id = text(body.requestId, "a creation reference", 36, true);
    if (!UUID_PATTERN.test(id)) throw new HttpError(400, "Invalid playlist reference.");
    const title = text(body.title, "a playlist name", 80, true);
    const description = text(body.description, "a playlist description", 300);
    const trackUris = body.trackUris;
    if (!Array.isArray(trackUris) || trackUris.length < 1 || trackUris.length > 50 || trackUris.some(uri => typeof uri !== "string" || !/^spotify:track:[A-Za-z0-9]{22}$/.test(uri))) {
      throw new HttpError(400, "Choose between 1 and 50 Spotify tracks.");
    }
    if (body.permission !== true) throw new HttpError(400, "Confirm that your playlist can be shared publicly.");
    await db.insert(sharedPlaylists).values({ id, ownerId: user.id, authorName: authorName(user), title, description, trackUris }).onConflictDoNothing();
    const [job] = await db.select().from(sharedPlaylists).where(eq(sharedPlaylists.id, id));
    if (job.ownerId !== user.id) throw new HttpError(403, "This creation belongs to a different account.");
    if (job.title !== title || job.description !== description || JSON.stringify(job.trackUris) !== JSON.stringify(trackUris)) throw new HttpError(400, "This attempt already uses a different playlist draft. Reload to start a new playlist.");
    if (job.status === "published") return json({ playlist: publicPlaylist(job) });
    if (job.status === "hidden") throw new HttpError(409, "This playlist post has been removed.");
    const [claimed] = await db.update(sharedPlaylists).set({ status: "working", updatedAt: new Date() }).where(and(eq(sharedPlaylists.id, id), or(
      eq(sharedPlaylists.status, "draft"), and(eq(sharedPlaylists.status, "working"), isNotNull(sharedPlaylists.spotifyId), lt(sharedPlaylists.updatedAt, new Date(Date.now() - 300000))),
    ))).returning();
    if (!claimed) throw new HttpError(409, "This playlist is already being created. If a previous attempt timed out, check Spotify before trying a new draft.");
    let spotifyId = job.spotifyId;
    try {
      if (!spotifyId) {
        const created = await spotifyRequest(user.id, "/me/playlists", { method: "POST", body: JSON.stringify({ name: title, description, public: true }) }) as { id: string };
        if (!created?.id || !spotifyIdPattern.test(created.id)) throw new HttpError(502, "Spotify returned an incomplete playlist. Check your Spotify account.");
        spotifyId = created.id;
        await db.update(sharedPlaylists).set({ spotifyId, updatedAt: new Date() }).where(eq(sharedPlaylists.id, id));
      }
      await spotifyRequest(user.id, `/playlists/${spotifyId}/items`, { method: "PUT", body: JSON.stringify({ uris: trackUris }) });
      const [published] = await db.update(sharedPlaylists).set({ status: "published", updatedAt: new Date() }).where(eq(sharedPlaylists.id, id)).returning();
      return json({ playlist: publicPlaylist(published) }, 201);
    } catch (error) {
      if (spotifyId || (error instanceof HttpError && error.status < 500)) await db.update(sharedPlaylists).set({ status: "draft", updatedAt: new Date() }).where(eq(sharedPlaylists.id, id)).catch(() => {});
      if (spotifyId) return json({ error: "Your playlist exists on Spotify, but finishing or sharing failed. Retry this same draft to finish without creating another playlist.", playlistUrl: `https://open.spotify.com/playlist/${spotifyId}` }, 502);
      throw error;
    }
  } catch (error) { return failure(error); }
};

export const config: Config = { path: "/api/spotify/:action", rateLimit: { windowSize: 60, windowLimit: 30, aggregateBy: "ip" } };
