# dear sunghoon ♡

A pastel, scrapbook-style fan site for Park Sunghoon (ENHYPEN), made by ENGENEs. Fans can fill **The Spotlight** photo album with their own photos, put a photo on the front-page polaroid, keep Hoon's latest Weverse note pinned on the home page, pin news to a shared board, post fanart and fancams, build playlists, take a quiz, and make a three-column photo strip in the online photo booth.

## Tech

- Static HTML/CSS/vanilla JS pages (`index.html`, `fanarts.html`)
- Netlify Functions (`netlify/functions`) for the APIs
- Netlify Database (Postgres) with Drizzle ORM for records (`db/schema.ts`, migrations in `netlify/database/migrations`)
- Netlify Blobs for uploaded photos and media
- Netlify Identity for fan accounts
- Spotify integration for shared playlists (see `spotify_setup.md`)

## Running locally

```bash
npm install
netlify dev --port 8889
```

After changing `db/schema.ts`, run `npx drizzle-kit generate --name <change>` to create a migration.
