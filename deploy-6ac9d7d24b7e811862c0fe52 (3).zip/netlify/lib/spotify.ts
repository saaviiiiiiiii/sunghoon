import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { spotifyConnections } from "../../db/schema.js";
import { HttpError } from "./http.js";

export function spotifySettings() {
  try {
    const clientId = process.env.SPOTIFY_CLIENT_ID;
    const redirectUri = process.env.SPOTIFY_REDIRECT_URI;
    const key = Buffer.from(process.env.SPOTIFY_TOKEN_ENCRYPTION_KEY || "", "base64");
    if (!clientId || !redirectUri || key.length !== 32) return null;
    const url = new URL(redirectUri);
    if (url.username || url.password || url.search || url.hash || url.pathname !== "/api/spotify/callback") return null;
    if (url.protocol !== "https:" && !(url.protocol === "http:" && url.hostname === "127.0.0.1")) return null;
    return { clientId, redirectUri, key };
  } catch { return null; }
}

export function requireSpotifySettings() {
  const settings = spotifySettings();
  if (!settings) throw new HttpError(503, "Spotify creation is waiting for the site owner's app configuration.");
  return settings;
}

export function encrypt(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", requireSpotifySettings().key, iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString("base64");
}

export function decrypt(value: string) {
  const data = Buffer.from(value, "base64");
  const cipher = createDecipheriv("aes-256-gcm", requireSpotifySettings().key, data.subarray(0, 12));
  cipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([cipher.update(data.subarray(28)), cipher.final()]).toString("utf8");
}

type Tokens = { access_token: string; refresh_token?: string; expires_in: number };

export async function tokenRequest(parameters: Record<string, string>): Promise<Tokens> {
  let response: Response;
  try {
    response = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: requireSpotifySettings().clientId, ...parameters }),
      signal: AbortSignal.timeout(12000),
    });
  } catch { throw new HttpError(504, "Spotify didn't respond. Please try again."); }
  if (!response.ok) throw new HttpError(response.status === 429 ? 429 : 401, "Spotify authorization expired or was declined. Connect your account again.");
  const tokens = await response.json() as Tokens;
  if (!tokens.access_token || !Number.isFinite(tokens.expires_in)) throw new HttpError(502, "Spotify returned an incomplete account response.");
  return tokens;
}

export async function saveConnection(ownerId: string, tokens: Tokens, previousRefresh?: string) {
  const refreshToken = tokens.refresh_token || previousRefresh;
  if (!refreshToken) throw new HttpError(401, "Reconnect Spotify to allow playlist creation.");
  const values = {
    ownerId, accessToken: encrypt(tokens.access_token), refreshToken: encrypt(refreshToken),
    expiresAt: new Date(Date.now() + tokens.expires_in * 1000),
  };
  await db.insert(spotifyConnections).values(values).onConflictDoUpdate({ target: spotifyConnections.ownerId, set: values });
}

async function accessToken(ownerId: string, forceRefresh = false) {
  const [connection] = await db.select().from(spotifyConnections).where(eq(spotifyConnections.ownerId, ownerId));
  if (!connection) throw new HttpError(401, "Connect your Spotify account first.");
  if (!forceRefresh && connection.expiresAt.getTime() > Date.now() + 60000) return decrypt(connection.accessToken);
  const refreshToken = decrypt(connection.refreshToken);
  const tokens = await tokenRequest({ grant_type: "refresh_token", refresh_token: refreshToken });
  await saveConnection(ownerId, tokens, refreshToken);
  return tokens.access_token;
}

export async function spotifyRequest(ownerId: string, path: string, options: RequestInit = {}, retried = false): Promise<unknown> {
  const token = await accessToken(ownerId, retried);
  let response: Response;
  try {
    response = await fetch(`https://api.spotify.com/v1${path}`, {
      ...options, headers: { ...options.headers, Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      signal: AbortSignal.timeout(12000),
    });
  } catch { throw new HttpError(504, "Spotify didn't respond. Check your Spotify account before retrying playlist creation."); }
  if (response.status === 401 && !retried) return spotifyRequest(ownerId, path, options, true);
  if (!response.ok) {
    const message = response.status === 403
      ? "Spotify hasn't allowed this account or action. The site owner may need to add you to the app's allowed users."
      : response.status === 429 ? "Spotify is busy. Please wait a little before trying again."
      : response.status === 401 ? "Reconnect your Spotify account to continue."
      : "Spotify couldn't complete that action. Please try again.";
    throw new HttpError(response.status >= 500 ? 502 : response.status, message);
  }
  if (response.status === 204) return null;
  return response.json();
}
