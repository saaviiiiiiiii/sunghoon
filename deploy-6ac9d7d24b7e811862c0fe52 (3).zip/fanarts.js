const artworkCards = () => [...document.querySelectorAll('.art-card')];
const filterButtons = [...document.querySelectorAll('[data-filter]')];
const artworkSearch = document.querySelector('#art-search');
const artworkDialog = document.querySelector('#art-dialog');
let activeCategory = 'all';
let previewCard;
let previewTrigger;

function visibleArtwork() {
  return artworkCards().filter(card => !card.hidden);
}

function filterArtwork() {
  const searchTerm = artworkSearch.value.trim().toLowerCase();
  artworkCards().forEach(card => {
    const matchesCategory = activeCategory === 'all' || card.dataset.category === activeCategory;
    const searchableText = `${card.textContent} ${card.dataset.category}`.toLowerCase();
    card.hidden = !matchesCategory || !searchableText.includes(searchTerm);
  });
  const resultCount = visibleArtwork().length;
  const total = artworkCards().length;
  document.querySelector('#result-count').textContent = `Showing ${resultCount} of ${total} artworks · 6 samples, ${total - 6} community posts loaded`;
  filterButtons[0].querySelector('span').textContent = String(total).padStart(2, '0');
  document.querySelector('#empty-state').hidden = resultCount !== 0;
  filterButtons.forEach(button => {
    const selected = button.dataset.filter === activeCategory;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
}

filterButtons.forEach(button => button.addEventListener('click', () => {
  activeCategory = button.dataset.filter;
  filterArtwork();
}));
artworkSearch.addEventListener('input', filterArtwork);
document.querySelector('#reset-filters').addEventListener('click', () => {
  activeCategory = 'all';
  artworkSearch.value = '';
  filterArtwork();
  filterButtons[0].focus();
});

function showArtwork(card) {
  previewCard = card;
  document.querySelector('#preview-art').replaceChildren(card.querySelector('.art-preview svg, .art-preview img').cloneNode(true));
  document.querySelector('#preview-title').textContent = card.dataset.title;
  document.querySelector('#preview-description').textContent = card.querySelector('p').textContent;
  document.querySelector('#preview-category').textContent = card.querySelector('.art-meta > span').textContent;
  document.querySelector('#preview-credit').textContent = card.dataset.artistCredit
    ? `Artist: ${card.dataset.artistCredit} · Shared by ${card.dataset.authorName}`
    : 'Original sample illustration · Not an artist submission or exact portrait.';
  const visibleCards = visibleArtwork();
  document.querySelector('#preview-position').textContent = `${visibleCards.indexOf(card) + 1} / ${visibleCards.length}`;
  document.querySelector('#previous-art').disabled = visibleCards.length < 2;
  document.querySelector('#next-art').disabled = visibleCards.length < 2;
}

document.querySelector('.art-grid').addEventListener('click', event => {
  const trigger = event.target.closest('.art-preview');
  if (!trigger) return;
  const card = trigger.closest('.art-card');
  previewTrigger = trigger;
  showArtwork(card);
  artworkDialog.showModal();
  document.body.classList.add('preview-open');
});

document.addEventListener('fanart-posts-updated', filterArtwork);
filterArtwork();

function changeArtwork(direction) {
  const visibleCards = visibleArtwork();
  const nextIndex = (visibleCards.indexOf(previewCard) + direction + visibleCards.length) % visibleCards.length;
  showArtwork(visibleCards[nextIndex]);
}

document.querySelector('#previous-art').addEventListener('click', () => changeArtwork(-1));
document.querySelector('#next-art').addEventListener('click', () => changeArtwork(1));
document.querySelector('.dialog-close').addEventListener('click', () => artworkDialog.close());
artworkDialog.addEventListener('click', event => {
  const bounds = artworkDialog.getBoundingClientRect();
  if (event.target === artworkDialog && (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom)) {
    artworkDialog.close();
  }
});
artworkDialog.addEventListener('keydown', event => {
  if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
    event.preventDefault();
    changeArtwork(event.key === 'ArrowRight' ? 1 : -1);
  }
});
artworkDialog.addEventListener('close', () => {
  document.body.classList.remove('preview-open');
  previewTrigger?.focus();
});
