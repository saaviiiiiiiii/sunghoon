// Dear Sunghoon scrapbook — guestbook and diary entries stay in this browser.
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
$$("nav a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

// Gallery category filters
$$(".filter-chip").forEach(button => {
  button.addEventListener("click", () => {
    $$(".filter-chip").forEach(chip => chip.classList.toggle("active", chip === button));
    const filter = button.dataset.filter;
    $$(".gallery-card").forEach(card => {
      card.hidden = filter !== "all" && card.dataset.category !== filter;
    });
  });
});

const safeRead = (key, fallback = []) => {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : fallback;
  } catch { return fallback; }
};
const safeWrite = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch { return false; }
};
const make = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};

// Fan guestbook
const guestbookEntries = $("#guestbookEntries");
function renderGuestbook() {
  const entries = safeRead("dearSunghoonGuestbook");
  guestbookEntries.replaceChildren();
  if (!entries.length) {
    guestbookEntries.append(make("p", "empty-state", "Your kind note could be the first one here ♡"));
    return;
  }
  entries.slice().reverse().forEach(entry => {
    const card = make("article", "guestbook-note");
    card.append(make("strong", "", `${entry.name} ♡`), make("p", "", entry.message));
    guestbookEntries.append(card);
  });
}
$("#guestbookForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = $("#fanName").value.trim();
  const message = $("#fanMessage").value.trim();
  if (!name || !message) return;
  const entries = safeRead("dearSunghoonGuestbook");
  entries.push({ name, message, createdAt: new Date().toISOString() });
  if (!safeWrite("dearSunghoonGuestbook", entries)) {
    alert("Your browser could not save this note. Check local storage settings and try again.");
    return;
  }
  $("#guestbookForm").reset();
  renderGuestbook();
});
renderGuestbook();

// Private fan diary
const diaryEntries = $("#diaryEntries");
function renderDiary() {
  const entries = safeRead("dearSunghoonDiary");
  diaryEntries.replaceChildren();
  if (!entries.length) {
    diaryEntries.append(make("p", "empty-state", "Your saved entries will appear here."));
    return;
  }
  entries.slice().reverse().forEach(entry => {
    const card = make("article", "diary-entry");
    card.append(make("h3", "", entry.title), make("time", "", new Date(entry.createdAt).toLocaleDateString()), make("p", "", entry.body));
    const remove = make("button", "delete-entry", "delete entry ×");
    remove.type = "button";
    remove.addEventListener("click", () => {
      const updated = safeRead("dearSunghoonDiary").filter(item => item.id !== entry.id);
      safeWrite("dearSunghoonDiary", updated);
      renderDiary();
    });
    card.append(remove);
    diaryEntries.append(card);
  });
}
$("#diaryForm").addEventListener("submit", event => {
  event.preventDefault();
  const title = $("#diaryTitle").value.trim();
  const body = $("#diaryText").value.trim();
  if (!title || !body) return;
  const entries = safeRead("dearSunghoonDiary");
  entries.push({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, title, body, createdAt: new Date().toISOString() });
  if (!safeWrite("dearSunghoonDiary", entries)) {
    $("#diaryStatus").textContent = "Could not save — check browser storage settings.";
    return;
  }
  $("#diaryForm").reset();
  $("#diaryStatus").textContent = "entry saved ♡";
  renderDiary();
});
renderDiary();

// The pin board is shared for everyone and lives in front-page.js.

// Five-question quiz: beginner-friendly and based on widely available public facts.
const quizQuestions = [
  { q: "Which group is Park Sunghoon a member of?", options: ["TXT", "ENHYPEN", "SEVENTEEN", "TREASURE"], answer: 1, note: "Sunghoon debuted as a member of ENHYPEN." },
  { q: "What sport did Sunghoon pursue before his idol career?", options: ["Figure skating", "Tennis", "Swimming", "Gymnastics"], answer: 0, note: "He trained and competed as a figure skater before debuting." },
  { q: "What is the name of ENHYPEN's fandom?", options: ["MOA", "CARAT", "ENGENE", "STAY"], answer: 2, note: "ENHYPEN's official fandom name is ENGENE." },
  { q: "Which TV competition helped form ENHYPEN?", options: ["Produce 101", "I-LAND", "Kingdom", "Road to Kingdom"], answer: 1, note: "ENHYPEN was formed through the survival show I-LAND." },
  { q: "Which of these is a good fan-community habit?", options: ["Sharing private details", "Spreading unconfirmed rumors", "Respecting boundaries and crediting creators", "Reposting everything without permission"], answer: 2, note: "Respect, privacy and creator credit help keep fandom spaces welcoming." }
];
let quizIndex = 0, quizScore = 0, quizLocked = false;
const quizQuestion = $("#quizQuestion"), quizOptions = $("#quizOptions"), quizFeedback = $("#quizFeedback");
const quizNext = $("#quizNext"), quizProgress = $("#quizProgress"), quizProgressBar = $("#quizProgressBar"), quizResult = $("#quizResult");
function renderQuestion() {
  const current = quizQuestions[quizIndex];
  quizLocked = false;
  quizProgress.textContent = `QUESTION ${quizIndex + 1} / ${quizQuestions.length}`;
  quizProgressBar.style.width = `${((quizIndex + 1) / quizQuestions.length) * 100}%`;
  quizQuestion.textContent = current.q;
  quizOptions.replaceChildren();
  quizFeedback.textContent = "";
  quizNext.hidden = true;
  quizResult.hidden = true;
  current.options.forEach((option, index) => {
    const button = make("button", "quiz-option", option);
    button.type = "button";
    button.addEventListener("click", () => {
      if (quizLocked) return;
      quizLocked = true;
      const correct = index === current.answer;
      if (correct) quizScore++;
      $$(".quiz-option", quizOptions).forEach((other, otherIndex) => {
        other.disabled = true;
        if (otherIndex === current.answer) other.classList.add("correct");
        else if (otherIndex === index) other.classList.add("wrong");
      });
      quizFeedback.textContent = `${correct ? "You got it! ♡ " : "Not quite — "} ${current.note}`;
      quizNext.hidden = false;
      quizNext.textContent = quizIndex === quizQuestions.length - 1 ? "see my result ✨" : "next question →";
    });
    quizOptions.append(button);
  });
}
quizNext.addEventListener("click", () => {
  if (quizIndex < quizQuestions.length - 1) {
    quizIndex++;
    renderQuestion();
  } else {
    quizQuestion.textContent = "Your little fan quiz result";
    quizOptions.replaceChildren();
    quizFeedback.textContent = "";
    quizNext.hidden = true;
    quizResult.hidden = false;
    let message = quizScore === 5 ? "Perfect score! Your fan trivia skills are sparkling. ✨" :
      quizScore >= 3 ? "A lovely score! Keep enjoying the music and making memories. ♡" :
      "A new scrapbook chapter awaits — explore, listen and try again! ❄";
    quizResult.replaceChildren(make("h3", "", `${quizScore} / ${quizQuestions.length} ♡`), make("p", "", message));
    const retry = make("button", "button button-pink", "play again ↻");
    retry.type = "button";
    retry.addEventListener("click", () => { quizIndex = 0; quizScore = 0; renderQuestion(); });
    quizResult.append(retry);
  }
});
renderQuestion();

// Online photobooth: photos stay local, and the generated strip can be downloaded.
let chosenFiles = [];
const photoUpload = $("#photoUpload"), photoStrip = $("#photoStrip"), stripCaption = $("#stripCaption"), downloadStrip = $("#downloadStrip");
photoUpload.addEventListener("change", () => {
  chosenFiles = [...photoUpload.files].filter(file => file.type.startsWith("image/")).slice(0, 6);
  if (photoUpload.files.length > 6) alert("Only the first six images will be used.");
});
$("#frameChoice").addEventListener("change", event => {
  photoStrip.classList.remove("frame-pink", "frame-blue", "frame-cream");
  photoStrip.classList.add(`frame-${event.target.value}`);
});
$("#boothCaption").addEventListener("input", event => {
  stripCaption.textContent = event.target.value || "a day to remember ♡";
});
$("#makeStrip").addEventListener("click", () => {
  if (!chosenFiles.length) {
    alert("Choose at least one photo first ♡");
    photoUpload.focus();
    return;
  }
  photoStrip.querySelectorAll(".strip-photo, .strip-empty, .strip-grid").forEach(node => node.remove());
  const grid = make("div", "strip-grid");
  chosenFiles.forEach(file => {
    const img = make("img", "strip-photo");
    img.src = URL.createObjectURL(file);
    img.alt = "Your uploaded photo";
    grid.append(img);
  });
  photoStrip.insertBefore(grid, stripCaption);
  downloadStrip.disabled = false;
});
downloadStrip.addEventListener("click", async () => {
  const images = $$(".strip-photo", photoStrip);
  if (!images.length) return;
  const frameColor = $("#frameChoice").value === "blue" ? "#dfebfa" : $("#frameChoice").value === "cream" ? "#fff2d8" : "#f9e8ef";
  const canvas = document.createElement("canvas");
  // Three-column strip: photos fill rows of three, left to right.
  const columns = 3, photoWidth = 300, photoHeight = 380, gap = 18, padding = 28, captionHeight = 76;
  const rows = Math.ceil(images.length / columns);
  const width = padding * 2 + columns * photoWidth + (columns - 1) * gap;
  canvas.width = width;
  canvas.height = padding * 2 + rows * photoHeight + (rows - 1) * gap + captionHeight;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = frameColor;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  for (const [index, img] of images.entries()) {
    const x = padding + (index % columns) * (photoWidth + gap);
    const y = padding + Math.floor(index / columns) * (photoHeight + gap);
    try {
      const bitmap = await createImageBitmap(img);
      const scale = Math.max(photoWidth / bitmap.width, photoHeight / bitmap.height);
      const sw = photoWidth / scale, sh = photoHeight / scale;
      const sx = (bitmap.width - sw) / 2, sy = (bitmap.height - sh) / 2;
      ctx.fillStyle = "#fffdfb";
      ctx.fillRect(x - 5, y - 5, photoWidth + 10, photoHeight + 10);
      ctx.drawImage(bitmap, sx, sy, sw, sh, x, y, photoWidth, photoHeight);
      bitmap.close();
    } catch {
      ctx.fillStyle = "#fffdfb"; ctx.fillRect(x, y, photoWidth, photoHeight);
    }
  }
  ctx.fillStyle = "#755c70";
  ctx.textAlign = "center";
  ctx.font = "32px Georgia, serif";
  const caption = ($("#boothCaption").value.trim() || "a day to remember ♡").slice(0, 50);
  ctx.fillText(caption, width / 2, canvas.height - 30);
  const link = document.createElement("a");
  link.download = "dear-sunghoon-photo-strip.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
});

// Smooth internal links are handled by CSS; keep the first view ready if a section is opened directly.
