import type { Config, Context } from "@netlify/functions";
import { and, desc, eq, lt, or } from "drizzle-orm";
import { db } from "../../db/index.js";
import { communityPosts, communityUploads } from "../../db/schema.js";
import { failure, HttpError, json, requireUser, sameOrigin, UUID_PATTERN } from "../lib/http.js";
import { publicPost, removeParts } from "../lib/posts.js";

export default async (request: Request, context: Context) => {
  try {
    if (request.method === "GET" && context.params.id) {
      const id = context.params.id;
      if (!UUID_PATTERN.test(id)) throw new HttpError(404, "Post not found.");
      const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
      if (!post) throw new HttpError(404, "Post not found.");
      return json({ post: publicPost(post) });
    }
    if (request.method === "GET" && !context.params.id) {
      const url = new URL(request.url);
      const kind = url.searchParams.get("kind");
      if (!kind || !["gallery", "fanart", "fancam"].includes(kind)) throw new HttpError(400, "Choose a post collection.");
      const cursor = url.searchParams.get("cursor");
      let cursorCondition;
      if (cursor) {
        if (!UUID_PATTERN.test(cursor)) throw new HttpError(400, "Invalid page marker.");
        const [anchor] = await db.select().from(communityPosts).where(and(eq(communityPosts.id, cursor), eq(communityPosts.kind, kind)));
        if (!anchor) throw new HttpError(400, "The collection changed. Refresh to continue.");
        cursorCondition = or(lt(communityPosts.createdAt, anchor.createdAt), and(eq(communityPosts.createdAt, anchor.createdAt), lt(communityPosts.id, anchor.id)));
      }
      const rows = await db.select().from(communityPosts).where(and(eq(communityPosts.kind, kind), cursorCondition)).orderBy(desc(communityPosts.createdAt), desc(communityPosts.id)).limit(13);
      return json({ posts: rows.slice(0, 12).map(publicPost), nextCursor: rows.length > 12 ? rows[11].id : null });
    }
    if (request.method !== "DELETE") throw new HttpError(405, "Method not allowed.");
    sameOrigin(request);
    const user = await requireUser();
    const id = context.params.id;
    if (!id || !UUID_PATTERN.test(id)) throw new HttpError(404, "Post not found.");
    const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
    if (!post) throw new HttpError(404, "Post not found.");
    if (post.ownerId !== user.id && !user.roles?.includes("admin")) throw new HttpError(403, "You can only remove your own posts.");
    await db.delete(communityPosts).where(eq(communityPosts.id, id));
    await db.delete(communityUploads).where(eq(communityUploads.id, id));
    await removeParts(`media/${id}`, post.partCount).catch(() => {});
    return json({ ok: true });
  } catch (error) { return failure(error); }
};

export const config: Config = { path: ["/api/posts", "/api/posts/:id"], rateLimit: { windowSize: 60, windowLimit: 60, aggregateBy: "ip" } };
