(() => {
  const host = document.querySelector("[data-playlist-maker]");
  if (!host || !window.Scrapbook) return;
  const { api, element, status, addActions, openAccount, ready } = window.Scrapbook;
  const maker = element("section", "playlist-maker");
  maker.setAttribute("aria-labelledby", "playlist-maker-title");
  maker.innerHTML = `<div class="playlist-maker-heading"><div><h3 id="playlist-maker-title">Make a playlist, pass it on.</h3>
    <p class="community-note">Connect your Spotify account, find songs, and arrange up to 50 tracks. Your finished playlist is public on Spotify and shared here.</p></div>
    <a class="spotify-attribution" href="https://open.spotify.com" target="_blank" rel="noopener">Spotify</a></div>
    <p class="community-status" data-spotify-connection role="status" aria-live="polite">Checking Spotify availability…</p>
    <div class="post-actions"><button class="community-button" type="button" data-spotify-connect disabled>connect Spotify</button><button class="community-button secondary" type="button" data-spotify-disconnect hidden>disconnect Spotify</button></div>
    <form data-track-search><fieldset disabled><label for="spotify-query">find a song or artist</label><div class="spotify-search-row"><input id="spotify-query" name="query" type="search" maxlength="100" placeholder="e.g. ENHYPEN" required><button class="community-button secondary" type="submit">search Spotify</button></div></fieldset></form>
    <p class="community-status" data-search-status role="status" aria-live="polite"></p><ul class="spotify-track-list" data-search-results></ul>
    <form data-playlist-create><fieldset disabled><label for="spotify-title">playlist name</label><input id="spotify-title" name="title" maxlength="80" placeholder="a little winter soundtrack" required>
    <label for="spotify-description">description (optional)</label><textarea id="spotify-description" name="description" rows="2" maxlength="300"></textarea>
    <p class="community-note" data-track-count>No tracks selected yet.</p><ol class="spotify-track-list" data-selected-tracks></ol>
    <label class="permission"><input name="permission" type="checkbox" required><span>Make this playlist public on Spotify and share its name, description, link, and my nickname on this site.</span></label>
    <div class="post-actions"><button class="community-button" type="submit" disabled>create & share playlist</button><button class="community-button secondary" type="button" data-new-draft>new draft</button></div>
    </fieldset><p class="community-status" data-create-status role="status" aria-live="polite"></p><a class="playlist-recovery-link" data-playlist-link target="_blank" rel="noopener" hidden>open your playlist on Spotify</a></form>
    <p class="community-note">Only your connected account can create playlists. Removing a shared post here doesn't delete the playlist from Spotify. Disconnecting removes this site's saved Spotify connection.</p>`;
  host.append(maker);
  const connect = maker.querySelector("[data-spotify-connect]");
  const disconnect = maker.querySelector("[data-spotify-disconnect]");
  const connectionStatus = maker.querySelector("[data-spotify-connection]");
  const searchForm = maker.querySelector("[data-track-search]");
  const searchStatus = maker.querySelector("[data-search-status]");
  const resultsList = maker.querySelector("[data-search-results]");
  const createForm = maker.querySelector("[data-playlist-create]");
  const selectedList = maker.querySelector("[data-selected-tracks]");
  const createStatus = maker.querySelector("[data-create-status]");
  const playlistLink = maker.querySelector("[data-playlist-link]");
  const feed = document.querySelector("[data-playlist-feed]");
  const tools = document.querySelector("[data-playlist-tools]");
  let configured = false;
  let connected = false;
  let creating = false;
  let selected = [];
  let searchResults = [];
  let requestId;

  function updateControls() {
    const enabled = configured && connected && Boolean(window.Scrapbook.user) && !creating;
    searchForm.querySelector("fieldset").disabled = !enabled;
    createForm.querySelector("fieldset").disabled = !enabled;
    createForm.querySelector("[type=submit]").disabled = !enabled || selected.length === 0;
    connect.disabled = !configured || creating;
    connect.hidden = connected;
    disconnect.hidden = !connected;
    disconnect.disabled = creating;
    connect.textContent = window.Scrapbook.user ? "connect Spotify" : "sign in to connect Spotify";
  }

  async function refreshConnection() {
    try {
      const result = await api("/api/spotify/status");
      configured = result.configured; connected = result.connected;
      status(connectionStatus, !configured
        ? "Spotify creation is waiting for the site owner's developer app setup. The playlist maker is ready, but search and creation stay off until it is activated."
        : connected ? "Spotify connected. Choose songs to start your playlist."
        : "Sign in to the scrapbook, then connect Spotify to search songs and create playlists.");
      const parameters = new URLSearchParams(window.location.search);
      if (parameters.has("spotify")) {
        if (parameters.get("spotify") === "failed") status(connectionStatus, "Spotify connection didn't finish. Check app access and try connecting again.", true);
        parameters.delete("spotify");
        history.replaceState(null, "", window.location.pathname + (parameters.size ? `?${parameters}` : "") + window.location.hash);
      }
    } catch { status(connectionStatus, "Spotify availability couldn't be checked. Reload to try again.", true); }
    updateControls();
  }

  connect.addEventListener("click", async () => {
    if (!window.Scrapbook.user) { openAccount(connect); return; }
    connect.disabled = true;
    status(connectionStatus, "Opening Spotify's account permission screen…");
    try { const result = await api("/api/spotify/connect", { method: "POST" }); window.location.assign(result.url); }
    catch (error) { status(connectionStatus, error.message, true); updateControls(); }
  });
  disconnect.addEventListener("click", async () => {
    disconnect.disabled = true;
    try { await api("/api/spotify/disconnect", { method: "POST" }); connected = false; status(connectionStatus, "Spotify disconnected. Your playlists on Spotify have not been deleted."); }
    catch (error) { status(connectionStatus, error.message, true); }
    updateControls();
  });

  function trackInfo(track) {
    const info = element("div");
    const link = element("a", "", track.title); link.href = track.url; link.target = "_blank"; link.rel = "noopener";
    link.setAttribute("aria-label", `${track.title} on Spotify`);
    info.append(link, element("small", "", track.artist));
    return info;
  }

  function renderSearch() {
    resultsList.replaceChildren();
    searchResults.forEach(track => {
      const item = element("li");
      const added = selected.some(value => value.uri === track.uri);
      const add = element("button", "community-button secondary", added ? "added" : "add");
      add.type = "button"; add.disabled = added || selected.length >= 50 || creating;
      add.setAttribute("aria-label", `Add ${track.title} to your playlist`);
      add.addEventListener("click", () => { if (selected.length < 50 && !selected.some(value => value.uri === track.uri)) { selected.push(track); renderSelected(); } });
      item.append(trackInfo(track), add); resultsList.append(item);
    });
  }

  function renderSelected() {
    selectedList.replaceChildren();
    selected.forEach((track, position) => {
      const item = element("li");
      const up = element("button", "community-button secondary", "↑"); up.type = "button"; up.disabled = position === 0;
      up.setAttribute("aria-label", `Move ${track.title} earlier`);
      const down = element("button", "community-button secondary", "↓"); down.type = "button"; down.disabled = position === selected.length - 1;
      down.setAttribute("aria-label", `Move ${track.title} later`);
      const remove = element("button", "community-button secondary", "remove"); remove.type = "button";
      remove.setAttribute("aria-label", `Remove ${track.title} from your draft`);
      up.addEventListener("click", () => { [selected[position - 1], selected[position]] = [selected[position], selected[position - 1]]; renderSelected(); });
      down.addEventListener("click", () => { [selected[position + 1], selected[position]] = [selected[position], selected[position + 1]]; renderSelected(); });
      remove.addEventListener("click", () => { selected.splice(position, 1); renderSelected(); });
      item.append(trackInfo(track), up, down, remove); selectedList.append(item);
    });
    maker.querySelector("[data-track-count]").textContent = selected.length ? `${selected.length} of 50 tracks · use arrows to arrange them` : "No tracks selected yet.";
    renderSearch(); updateControls();
  }

  searchForm.addEventListener("submit", async event => {
    event.preventDefault();
    const button = searchForm.querySelector("[type=submit]");
    button.disabled = true; status(searchStatus, "Searching Spotify…");
    try {
      const result = await api(`/api/spotify/search?q=${encodeURIComponent(searchForm.elements.query.value.trim())}`);
      searchResults = result.tracks; renderSearch();
      status(searchStatus, searchResults.length ? `${searchResults.length} Spotify results. Add songs to your draft below.` : "No tracks found. Try another title or artist.");
    } catch (error) { status(searchStatus, error.message, true); }
    finally { button.disabled = false; }
  });

  function renderPlaylist(playlist, prepend = false) {
    if (document.getElementById(`playlist-${playlist.id}`)) return;
    const card = element("article", "playlist-card community-card"); card.id = `playlist-${playlist.id}`;
    card.append(element("span", "spotify-attribution", "Spotify · community playlist"), element("h3", "", playlist.title),
      element("p", "post-caption", playlist.description), element("span", "post-byline", `${playlist.trackCount} tracks · shared by ${playlist.authorName}`));
    const listen = element("a", "community-button secondary", "open on Spotify"); listen.href = playlist.url; listen.target = "_blank"; listen.rel = "noopener";
    card.append(listen);
    addActions(card, playlist.ownerId, playlist.url, () => api(`/api/spotify/playlists?id=${encodeURIComponent(playlist.id)}`, { method: "DELETE" }));
    if (prepend) feed.prepend(card); else feed.append(card);
  }

  createForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (creating || !createForm.reportValidity() || !selected.length) return;
    creating = true; updateControls(); renderSearch(); createForm.setAttribute("aria-busy", "true");
    requestId ||= crypto.randomUUID(); playlistLink.hidden = true;
    status(createStatus, "Creating your public playlist on Spotify, then sharing it here…");
    try {
      const result = await api("/api/spotify/create", { method: "POST", json: {
        requestId, title: createForm.elements.title.value.trim(), description: createForm.elements.description.value.trim(),
        trackUris: selected.map(track => track.uri), permission: createForm.elements.permission.checked,
      } });
      renderPlaylist(result.playlist, true);
      playlistLink.href = result.playlist.url; playlistLink.hidden = false;
      requestId = null; selected = []; createForm.reset();
      status(createStatus, "Created on Spotify and shared with the scrapbook. Your playlist is ready.");
    } catch (error) {
      status(createStatus, error.message, true);
      const recover = error.data?.playlistUrl;
      if (typeof recover === "string" && /^https:\/\/open\.spotify\.com\/playlist\/[A-Za-z0-9]{22}$/.test(recover)) { playlistLink.href = recover; playlistLink.hidden = false; }
    } finally { creating = false; createForm.removeAttribute("aria-busy"); renderSelected(); }
  });
  maker.querySelector("[data-new-draft]").addEventListener("click", () => {
    const attempted = Boolean(requestId);
    selected = []; requestId = null; createForm.reset(); playlistLink.hidden = true; renderSelected();
    status(createStatus, attempted ? "New draft started. A previous attempt may already exist on Spotify; check your account before creating another." : "New draft started.");
  });

  const feedStatus = element("p", "community-status"); feedStatus.setAttribute("role", "status");
  const more = element("button", "community-button secondary", "load more playlists"); more.type = "button"; more.hidden = true;
  tools.append(feedStatus, more);
  let cursor;
  let loading = false;
  async function loadPlaylists() {
    if (loading) return;
    loading = true; more.disabled = true; status(feedStatus, "Loading shared Spotify playlists…");
    try {
      const result = await api(`/api/spotify/playlists${cursor ? `?cursor=${encodeURIComponent(cursor)}` : ""}`);
      result.playlists.forEach(playlist => renderPlaylist(playlist)); cursor = result.nextCursor;
      more.hidden = !cursor; more.textContent = "load more playlists";
      status(feedStatus, feed.children.length ? "" : "No community playlists yet. The first soundtrack can be yours once Spotify is activated.");
    } catch { status(feedStatus, "Shared playlists couldn't load. Your saved playlists have not been removed.", true); more.hidden = false; more.textContent = "retry loading playlists"; }
    finally { loading = false; more.disabled = false; }
  }
  more.addEventListener("click", loadPlaylists);
  ready.then(refreshConnection); loadPlaylists();
})();
