(() => {
  const PHOTO_BYTES = 3 * 1024 * 1024;
  const VIDEO_BYTES = 15 * 1024 * 1024;
  let currentUser = null;
  const feeds = new Map();

  function element(tag, className, content) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (content !== undefined) node.textContent = content;
    return node;
  }

  function status(node, message, isError = false) {
    node.textContent = message;
    node.dataset.error = String(isError);
  }

  async function api(url, options = {}) {
    const { json: body, ...rest } = options;
    let response;
    try {
      response = await fetch(url, {
        cache: "no-store", signal: AbortSignal.timeout(60000), ...rest,
        ...(body !== undefined ? { headers: { "Content-Type": "application/json", ...rest.headers }, body: JSON.stringify(body) } : {}),
      });
    } catch { throw new Error("Connection interrupted. Your file or draft is still here; try again."); }
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(result.error || "This action couldn't finish. Please try again.");
      error.data = result;
      error.status = response.status;
      throw error;
    }
    return result;
  }

  const dialog = element("dialog", "account-dialog");
  dialog.id = "fan-account-dialog";
  dialog.setAttribute("aria-labelledby", "account-title");
  dialog.innerHTML = `<button type="button" class="dialog-dismiss" aria-label="Close account dialog">×</button>
    <h2 id="account-title">Your fan account</h2><p class="community-note">A public nickname for your posts. Your email is only used for signing in.</p>
    <div class="account-tabs"><button class="community-button" type="button" data-account-mode="login">sign in</button><button class="community-button secondary" type="button" data-account-mode="signup">join</button></div>
    <form id="account-form"><label data-name-label for="account-name" hidden>public nickname</label><input id="account-name" name="name" maxlength="40" autocomplete="nickname" hidden>
    <label data-email-label for="account-email">email</label><input id="account-email" name="email" type="email" autocomplete="email" maxlength="254" required>
    <label data-password-label for="account-password">password</label><input id="account-password" name="password" type="password" autocomplete="current-password" maxlength="256" required>
    <button class="community-button" type="submit">sign in</button></form>
    <button class="community-button secondary" type="button" data-recover>forgot password</button><p class="community-status" role="status" aria-live="polite"></p>`;
  document.body.append(dialog);
  const accountForm = dialog.querySelector("form");
  const accountStatus = dialog.querySelector(".community-status");
  let accountMode = "login";
  let recoveryToken = null;
  let accountTrigger;

  function setAccountMode(mode) {
    accountMode = mode;
    const joining = mode === "signup";
    const resetting = mode === "reset";
    dialog.querySelector("[data-name-label]").hidden = !joining;
    accountForm.elements.name.hidden = !joining;
    accountForm.elements.name.required = joining;
    dialog.querySelector("[data-email-label]").hidden = resetting;
    accountForm.elements.email.hidden = resetting;
    accountForm.elements.email.required = !resetting;
    dialog.querySelector("[data-password-label]").hidden = mode === "recover";
    accountForm.elements.password.hidden = mode === "recover";
    accountForm.elements.password.required = mode !== "recover";
    accountForm.elements.password.minLength = joining || resetting ? 8 : 1;
    accountForm.elements.password.autocomplete = joining || resetting ? "new-password" : "current-password";
    dialog.querySelector(".account-tabs").hidden = resetting;
    dialog.querySelector("[data-recover]").hidden = resetting || mode === "recover";
    accountForm.querySelector("[type=submit]").textContent = { login: "sign in", signup: "create account", recover: "send reset link", reset: "set new password" }[mode];
    status(accountStatus, "");
  }

  function openAccount(trigger) {
    accountTrigger = trigger;
    if (!recoveryToken) setAccountMode("login");
    if (!dialog.open) dialog.showModal();
  }

  dialog.querySelector(".dialog-dismiss").addEventListener("click", () => dialog.close());
  dialog.addEventListener("close", () => { accountForm.elements.password.value = ""; accountTrigger?.focus(); });
  dialog.querySelectorAll("[data-account-mode]").forEach(button => button.addEventListener("click", () => setAccountMode(button.dataset.accountMode)));
  dialog.querySelector("[data-recover]").addEventListener("click", () => setAccountMode("recover"));
  accountForm.addEventListener("submit", async event => {
    event.preventDefault();
    const submit = accountForm.querySelector("[type=submit]");
    submit.disabled = true;
    status(accountStatus, "Working on your account…");
    try {
      const result = await api("/api/account", { method: "POST", json: {
        action: accountMode, email: accountForm.elements.email.value,
        password: accountForm.elements.password.value, name: accountForm.elements.name.value,
        ...(recoveryToken ? { token: recoveryToken } : {}),
      } });
      accountForm.elements.password.value = "";
      if (result.ok) window.location.reload();
      else status(accountStatus, result.message || "Check your email for the next step.");
    } catch (error) { status(accountStatus, error.message, true); }
    finally { submit.disabled = false; }
  });

  document.addEventListener("click", event => {
    const trigger = event.target.closest("[data-account-open]");
    if (trigger) openAccount(trigger);
  });
  document.querySelectorAll("[data-account-logout]").forEach(button => button.addEventListener("click", async () => {
    button.disabled = true;
    try { await api("/api/account", { method: "POST", json: { action: "logout" } }); window.location.reload(); }
    catch (error) { status(document.querySelector("[data-account-label]"), error.message, true); }
    finally { button.disabled = false; }
  }));

  async function loadAccount() {
    const hash = new URLSearchParams(window.location.hash.slice(1));
    const confirmation = hash.get("confirmation_token");
    recoveryToken = hash.get("recovery_token");
    if (confirmation || recoveryToken) {
      history.replaceState(null, "", window.location.pathname + window.location.search);
      if (confirmation) {
        try { await api("/api/account", { method: "POST", json: { action: "confirm", token: confirmation } }); window.location.reload(); return; }
        catch (error) { openAccount(); status(accountStatus, "This confirmation link couldn't be used. Sign in if already confirmed, or request a fresh link by joining again.", true); }
      } else { setAccountMode("reset"); openAccount(); }
    }
    try {
      const result = await api("/api/account");
      currentUser = result.user;
      document.querySelectorAll("[data-account-label]").forEach(node => {
        if (currentUser) node.textContent = `Signed in as ${currentUser.name}. Your posts are shared with everyone.`;
      });
    } catch {
      document.querySelectorAll("[data-account-label]").forEach(node => { node.textContent = "Sign-in is temporarily unavailable. Please try again later."; });
    }
    document.querySelectorAll("[data-account-panel] [data-account-open]").forEach(node => { node.hidden = Boolean(currentUser); });
    document.querySelectorAll("[data-account-logout]").forEach(node => { node.hidden = !currentUser; });
    document.dispatchEvent(new Event("fan-auth-change"));
  }

  function addActions(card, ownerId, shareUrl, remove) {
    const actions = element("div", "post-actions");
    const feedback = element("p", "community-status");
    feedback.setAttribute("role", "status");
    const share = element("button", "community-button secondary", "share");
    share.type = "button";
    share.addEventListener("click", async () => {
      try {
        if (navigator.share) await navigator.share({ url: shareUrl, title: card.querySelector("h3, :scope > p")?.textContent || "From the scrapbook" });
        else { await navigator.clipboard.writeText(shareUrl); status(feedback, "Link copied."); }
      } catch (error) {
        if (error.name !== "AbortError") status(feedback, `Share this link: ${shareUrl}`);
      }
    });
    actions.append(share);
    const removeButton = element("button", "community-button secondary", "remove");
    const cancel = element("button", "community-button secondary", "cancel");
    removeButton.type = cancel.type = "button";
    cancel.hidden = true;
    let confirmed = false;
    const updateOwner = () => { removeButton.hidden = !(currentUser && (currentUser.id === ownerId || currentUser.admin)); if (removeButton.hidden) cancel.hidden = true; };
    updateOwner();
    document.addEventListener("fan-auth-change", updateOwner);
    cancel.addEventListener("click", () => { confirmed = false; cancel.hidden = true; removeButton.textContent = "remove"; });
    removeButton.addEventListener("click", async () => {
      if (!confirmed) { confirmed = true; cancel.hidden = false; removeButton.textContent = "remove for everyone?"; return; }
      removeButton.disabled = true;
      try {
        await remove();
        document.removeEventListener("fan-auth-change", updateOwner);
        card.remove();
        document.dispatchEvent(new Event("fanart-posts-updated"));
      } catch (error) { status(feedback, error.message, true); removeButton.disabled = false; }
    });
    actions.append(removeButton, cancel);
    card.append(actions, feedback);
  }

  function renderPost(post, prepend = false) {
    const feed = feeds.get(post.kind);
    if (!feed || document.getElementById(`post-${post.id}`)) return;
    const card = element("article", "community-card");
    card.id = `post-${post.id}`;
    card.dataset.category = post.category;
    if (post.kind === "gallery") {
      card.classList.add("polaroid", "gallery-card", "tilt-left");
      const imageContainer = element("div", "gallery-image");
      const link = element("a");
      link.href = post.url;
      link.target = "_blank";
      link.rel = "noopener";
      link.setAttribute("aria-label", `View ${post.title} full size`);
      const photo = element("img", "posted-photo");
      photo.src = post.url; photo.alt = post.title; photo.loading = "lazy";
      link.append(photo); imageContainer.append(link); card.append(imageContainer, element("p", "", post.title), element("p", "post-caption", post.caption));
      const filter = document.querySelector(".filter-chip.active")?.dataset.filter || "all";
      card.hidden = filter !== "all" && filter !== post.category;
    } else if (post.kind === "fanart") {
      card.classList.add("art-card");
      card.dataset.title = post.title; card.dataset.artistCredit = post.artistCredit; card.dataset.authorName = post.authorName;
      const preview = element("button", "art-preview");
      preview.type = "button"; preview.setAttribute("aria-label", `View ${post.title}`);
      const photo = element("img"); photo.src = post.url; photo.alt = `${post.title}, artwork by ${post.artistCredit}`; photo.loading = "lazy";
      preview.append(photo, element("span", "art-open", "take a closer look"));
      const meta = element("div", "art-meta"); meta.append(element("span", "", post.category), element("span", "sample-label", "community"));
      card.append(preview, meta, element("h3", "", post.title), element("p", "post-caption", post.caption), element("p", "", `Artist: ${post.artistCredit}`));
    } else {
      card.classList.add("community-video");
      const video = element("video"); video.controls = true; video.preload = "metadata"; video.playsInline = true; video.src = post.url;
      video.setAttribute("aria-label", post.title);
      const fallback = element("a", "", "Open this video"); fallback.href = post.url; video.append(fallback);
      card.append(video, element("h3", "", post.title), element("p", "post-caption", post.caption));
    }
    card.append(element("span", "post-byline", `Shared by ${post.authorName} · ${new Date(post.createdAt).toLocaleDateString()}`));
    const path = post.kind === "fanart" ? "/fanarts.html" : "/index.html";
    addActions(card, post.ownerId, `${window.location.origin}${path}#post-${post.id}`, () => api(`/api/posts/${post.id}`, { method: "DELETE" }));
    if (prepend) feed.container.prepend(card); else feed.container.append(card);
    document.dispatchEvent(new Event("fanart-posts-updated"));
    return card;
  }

  document.querySelectorAll("[data-post-feed]").forEach(container => {
    const kind = container.dataset.postFeed;
    const tools = document.querySelector(`[data-feed-tools="${kind}"]`);
    const feedback = element("p", "community-status"); feedback.setAttribute("role", "status");
    const more = element("button", "community-button secondary", "load more posts"); more.type = "button"; more.hidden = true;
    tools.append(feedback, more);
    const feed = { container, cursor: null, loading: false, loaded: false };
    feeds.set(kind, feed);
    async function load() {
      if (feed.loading) return;
      feed.loading = true; more.disabled = true;
      status(feedback, "Loading community posts…");
      try {
        const result = await api(`/api/posts?kind=${kind}${feed.cursor ? `&cursor=${encodeURIComponent(feed.cursor)}` : ""}`);
        result.posts.forEach(post => renderPost(post));
        feed.cursor = result.nextCursor; feed.loaded = true;
        more.hidden = !result.nextCursor; more.textContent = "load more posts";
        status(feedback, container.querySelector(".community-card") ? "" : "No community posts yet. Add the first one below.");
      } catch (error) {
        status(feedback, "Community posts couldn't load. Your saved posts have not been removed.", true);
        more.hidden = false; more.textContent = "retry loading posts";
      } finally { feed.loading = false; more.disabled = false; }
    }
    more.addEventListener("click", load); load();
  });

  document.querySelectorAll("[data-post-composer]").forEach(host => {
    const kind = host.dataset.postComposer;
    const video = kind === "fancam";
    const art = kind === "fanart";
    const guestOk = kind === "gallery";
    const composer = element("details", "post-composer");
    composer.open = guestOk;
    const prefix = `compose-${kind}`;
    composer.innerHTML = `<summary>${art ? "post your fanart" : video ? "post a fancam video" : "post a photo from your computer — no account needed ♡"}</summary>
      <p class="community-note">${video ? "MP4 or WebM, up to 15 MB. Short clips work best. Videos are hosted here and visible to everyone." : "JPG, PNG or WebP, up to 3 MB. This adds a new post without replacing an existing picture."}</p>
      <button class="community-button secondary" type="button" data-account-open>${guestOk ? "sign in (optional)" : "sign in to post"}</button>
      <form><fieldset disabled><div class="composer-fields">
      ${guestOk ? `<div class="full-width" data-guest-name><label for="${prefix}-guest">your nickname (optional — no account needed)</label><input id="${prefix}-guest" name="guestName" maxlength="40" placeholder="guest ENGENE"></div>` : ""}
      <div><label for="${prefix}-title">title</label><input id="${prefix}-title" name="title" maxlength="80" required></div>
      <div><label for="${prefix}-theme">theme</label><select id="${prefix}-theme" name="category"><option value="stage">on stage</option><option value="soft">soft moments</option><option value="winter">winter mood</option></select></div>
      <div class="full-width"><label for="${prefix}-caption">caption (optional)</label><textarea id="${prefix}-caption" name="caption" rows="2" maxlength="500"></textarea></div>
      ${art ? `<div class="full-width"><label for="${prefix}-credit">artist credit (use your name for your own art)</label><input id="${prefix}-credit" name="artistCredit" maxlength="100" required></div>` : ""}
      <div class="full-width"><label for="${prefix}-file">${video ? "your video" : "your photo"}</label><input id="${prefix}-file" name="media" type="file" accept="${video ? "video/mp4,video/webm" : "image/jpeg,image/png,image/webp"}" required><div class="preview-holder"></div></div></div>
      <label class="permission"><input name="permission" type="checkbox" required><span>I made this ${video ? "video" : "image"} or have permission to share it publicly${art ? ", and I have credited the artist" : ""}. It contains no private information.</span></label>
      <button class="community-button" type="submit">${video ? "upload & post video" : "upload & post photo"}</button></fieldset>
      <progress class="upload-progress" max="100" value="0" hidden aria-label="Upload progress"></progress><p class="community-status" role="status" aria-live="polite"></p></form>`;
    host.append(composer);
    const form = composer.querySelector("form");
    const fieldset = form.querySelector("fieldset");
    const feedback = form.querySelector(".community-status");
    const progress = form.querySelector("progress");
    const holder = composer.querySelector(".preview-holder");
    let previewUrl;
    let busy = false;
    let attempt;
    const updateAuth = () => {
      fieldset.disabled = busy || (!currentUser && !guestOk);
      composer.querySelector("[data-account-open]").hidden = Boolean(currentUser);
      const guestName = composer.querySelector("[data-guest-name]");
      if (guestName) guestName.hidden = Boolean(currentUser);
    };
    updateAuth();
    document.addEventListener("fan-auth-change", updateAuth);
    form.elements.media.addEventListener("change", () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      holder.replaceChildren(); attempt = null; form.elements.media.setCustomValidity("");
      const file = form.elements.media.files[0];
      if (!file) return;
      const types = video ? ["video/mp4", "video/webm"] : ["image/jpeg", "image/png", "image/webp"];
      if (!types.includes(file.type) || !file.size || file.size > (video ? VIDEO_BYTES : PHOTO_BYTES)) {
        const message = video ? "Choose an MP4 or WebM video no larger than 15 MB." : "Choose a JPG, PNG or WebP photo no larger than 3 MB.";
        form.elements.media.setCustomValidity(message); status(feedback, message, true); return;
      }
      previewUrl = URL.createObjectURL(file);
      const preview = element(video ? "video" : "img", "upload-preview");
      if (video) { preview.controls = true; preview.preload = "metadata"; preview.playsInline = true; preview.setAttribute("aria-label", "Your video preview"); }
      else preview.alt = "Your selected photo preview";
      preview.src = previewUrl; holder.append(preview);
      form.elements.media.setCustomValidity("Wait for the file preview to load.");
      preview.addEventListener(video ? "loadedmetadata" : "load", () => { form.elements.media.setCustomValidity(""); status(feedback, "Preview ready. Posting shares this file with everyone."); }, { once: true });
      preview.addEventListener("error", () => { form.elements.media.setCustomValidity("This file can't be previewed. Try a different file."); status(feedback, "This file can't be previewed. Try a different file.", true); }, { once: true });
    });
    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (!currentUser && !guestOk) { openAccount(); return; }
      if (busy || !form.reportValidity()) return;
      const file = form.elements.media.files[0];
      if (!file) return;
      const payload = { kind, title: form.elements.title.value.trim(), caption: form.elements.caption.value.trim(), category: form.elements.category.value,
        artistCredit: form.elements.artistCredit?.value.trim() || "", contentType: file.type, size: file.size, permission: form.elements.permission.checked,
        ...(currentUser ? {} : { guestName: form.elements.guestName?.value.trim() || "" }) };
      const fingerprint = JSON.stringify(payload);
      busy = true; updateAuth(); form.setAttribute("aria-busy", "true"); progress.hidden = false; progress.value = 0;
      status(feedback, "Starting your upload…");
      try {
        if (!attempt || attempt.file !== file || attempt.fingerprint !== fingerprint) {
          const upload = await api("/api/uploads", { method: "POST", json: payload });
          attempt = { ...upload, file, fingerprint };
        }
        let post;
        const partCount = Math.ceil(file.size / attempt.partBytes);
        for (let part = 0; part < partCount; part++) {
          status(feedback, `Uploading part ${part + 1} of ${partCount}…`);
          const result = await api(`/api/uploads/${attempt.id}/parts/${part}`, { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: file.slice(part * attempt.partBytes, (part + 1) * attempt.partBytes) });
          if (result.published) { post = result.post; break; }
          progress.value = Math.round((part + 1) / partCount * 90);
        }
        if (!post) { status(feedback, "Checking your file and publishing…"); post = (await api(`/api/uploads/${attempt.id}/publish`, { method: "POST" })).post; }
        renderPost(post, true); progress.value = 100; form.reset(); holder.replaceChildren();
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        previewUrl = null; attempt = null;
        status(feedback, "Posted! Your new memory is saved and visible to everyone.");
      } catch (error) {
        if (error.status === 410) attempt = null;
        status(feedback, error.message, true);
      } finally { busy = false; updateAuth(); form.removeAttribute("aria-busy"); }
    });
  });

  const ready = loadAccount();
  window.Scrapbook = { api, element, status, ready, openAccount, addActions, get user() { return currentUser; } };
  const linked = /^#post-([0-9a-f-]{36})$/.exec(window.location.hash);
  if (linked) api(`/api/posts/${linked[1]}`).then(({ post }) => {
    const card = document.getElementById(`post-${post.id}`) || renderPost(post, true);
    card?.scrollIntoView({ block: "center" });
  }).catch(() => {
    const node = document.querySelector(".feed-tools .community-status");
    if (node) status(node, "That shared post is no longer available.", true);
  });
})();
