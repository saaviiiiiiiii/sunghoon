import { randomUUID } from "node:crypto";
import type { Config } from "@netlify/functions";
import { desc } from "drizzle-orm";
import { db } from "../../db/index.js";
import { weverseNotes } from "../../db/schema.js";
import { authorName, failure, HttpError, json, readJson, requireUser, sameOrigin, text } from "../lib/http.js";

const publicNote = (note: typeof weverseNotes.$inferSelect) => ({
  id: note.id, body: note.body, postedOn: note.postedOn, authorName: note.authorName, createdAt: note.createdAt,
});

export default async (request: Request) => {
  try {
    if (request.method === "GET") {
      const rows = await db.select().from(weverseNotes).orderBy(desc(weverseNotes.createdAt)).limit(6);
      return json({ notes: rows.map(publicNote) });
    }
    if (request.method !== "POST") throw new HttpError(405, "Method not allowed.");
    sameOrigin(request);
    const user = await requireUser();
    const body = await readJson(request);
    const postedOn = text(body.postedOn ?? "", "the date it was posted", 10);
    if (postedOn && !/^\d{4}-\d{2}-\d{2}$/.test(postedOn)) throw new HttpError(400, "Enter the date as YYYY-MM-DD.");
    const [note] = await db.insert(weverseNotes).values({
      id: randomUUID(), ownerId: user.id, authorName: authorName(user),
      body: text(body.body, "Sunghoon's note", 300, true), postedOn,
    }).returning();
    return json({ note: publicNote(note) }, 201);
  } catch (error) { return failure(error); }
};

export const config: Config = { path: "/api/weverse-note", rateLimit: { windowSize: 60, windowLimit: 30, aggregateBy: "ip" } };
