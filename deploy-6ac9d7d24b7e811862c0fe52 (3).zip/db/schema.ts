import { index, integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const albumPhotos = pgTable("album_photos", {
  slot: text("slot").primaryKey(),
  imageKey: text("image_key").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const communityPosts = pgTable("community_posts", {
  id: uuid("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  authorName: text("author_name").notNull(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  caption: text("caption").notNull(),
  category: text("category").notNull(),
  artistCredit: text("artist_credit").notNull().default(""),
  contentType: text("content_type").notNull(),
  mediaBytes: integer("media_bytes").notNull(),
  partCount: integer("part_count").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("community_posts_kind_created_idx").on(table.kind, table.createdAt)]);

export const communityUploads = pgTable("community_uploads", {
  id: uuid("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  authorName: text("author_name").notNull(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  caption: text("caption").notNull(),
  category: text("category").notNull(),
  artistCredit: text("artist_credit").notNull(),
  contentType: text("content_type").notNull(),
  sourceBytes: integer("source_bytes").notNull(),
  partCount: integer("part_count").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("community_uploads_owner_created_idx").on(table.ownerId, table.createdAt)]);

export const spotifyConnections = pgTable("spotify_connections", {
  ownerId: text("owner_id").primaryKey(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const spotifyStates = pgTable("spotify_states", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  verifier: text("verifier").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const sharedPlaylists = pgTable("shared_playlists", {
  id: uuid("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  authorName: text("author_name").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  trackUris: jsonb("track_uris").$type<string[]>().notNull(),
  spotifyId: text("spotify_id"),
  status: text("status").notNull().default("draft"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("shared_playlists_status_created_idx").on(table.status, table.createdAt)]);

export const weverseNotes = pgTable("weverse_notes", {
  id: uuid("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  authorName: text("author_name").notNull(),
  body: text("body").notNull(),
  postedOn: text("posted_on").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("weverse_notes_created_idx").on(table.createdAt)]);

export const pinboardUpdates = pgTable("pinboard_updates", {
  id: uuid("id").primaryKey(),
  ownerId: text("owner_id").notNull(),
  authorName: text("author_name").notNull(),
  tag: text("tag").notNull().default(""),
  title: text("title").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, table => [index("pinboard_updates_created_idx").on(table.createdAt)]);
